# Cross-Dataset Explainable Ambiguity Detection and Automatic Software Requirement Refinement Using Domain-Adaptive RoBERTa

This repository contains the complete research-grade implementation of a machine learning and full-stack software system designed to automatically detect, explain, and refine ambiguous statements in Software Requirement Specifications (SRS).

---

## 🔬 Project Overview & Methodology

Software engineering projects frequently fail or experience massive cost overruns due to poor requirement engineering. This project resolves SRS ambiguities by implementing a state-of-the-art NLP pipeline:

1. **Domain-Adaptive Pretraining (DAPT):** We perform Masked Language Modeling (MLM) on a large corpus of software requirements to adapt `roberta-base` to the unique lexicon and grammatical structures of software specifications.
2. **Ambiguity Classification:** A supervised sequence classification head is trained on a merged, cleaned dataset compiling the PROMISE dataset, PURE dataset, and requirement smell specifications to classify requirements into *Ambiguous* (1) vs *Non-Ambiguous* (0).
3. **Explainable AI (XAI):** For every prediction, local token-attribution weights are calculated using LIME and SHAP, providing visual attributions of which subjective words or terms (e.g., "quickly", "user-friendly") triggered the classifier.
4. **Requirement Refinement:** Ambiguous inputs are routed to a hybrid refinement engine combining regular expression grammatical templates and local sequence-to-sequence LLM generation (via Flan-T5) to produce unambiguous, measurable, and testable outputs (e.g., "The system shall load pages within 1.5 seconds under a load of 100 concurrent requests").

---

## 🛠 Project Directory Structure

```
.
├── backend/
│   ├── app/
│   │   ├── ml/
│   │   │   ├── classifier.py       # RoBERTa classification wrapper
│   │   │   ├── explainability.py   # LIME & SHAP XAI Engines
│   │   │   └── refiner.py          # Rule + T5 Refinement
│   │   ├── routers/
│   │   │   ├── auth.py             # User Signup/Login API
│   │   │   ├── predict.py          # /predict classification endpoint
│   │   │   ├── refine.py           # /refine requirement refiner
│   │   │   ├── upload.py           # /upload bulk CSV analyzer
│   │   │   ├── metrics.py          # /metrics benchmarks fetcher
│   │   │   ├── history.py          # /history audit logs
│   │   │   └── reports.py          # /reports dynamic PDF exporter
│   │   ├── config.py               # Settings manager (Pydantic)
│   │   ├── database.py             # SQLite/PostgreSQL connection layer
│   │   ├── models.py               # Database ORM models
│   │   └── schemas.py              # Request/Response schemas
│   └── requirements.txt            # Backend dependencies
├── datasets/
│   ├── download_and_prep.py        # Dataset compiles & stats report script
│   └── dataset_report.html         # Generated statistics visualization
├── frontend/                       # Angular 19 Standalone UI Application
│   └── src/
│       └── app/
│           ├── components/
│           │   ├── auth/           # Login/Signup view panel
│           │   ├── dashboard/      # KPI metrics & Chart.js graph
│           │   ├── analyzer/       # Single analysis + SHAP/LIME rendering
│           │   ├── upload/         # CSV Drag-Drop list + exporter
│           │   ├── refinement/     # Compare side-by-side card + TXT download
│           │   └── reports/        # Convergence plots, CM, PDF download
│           └── services/
│               └── api.service.ts  # Backend API client calls
├── research/
│   ├── compare_models.py           # Baselines training & benchmarking
│   ├── generate_diagrams.py        # Academic PNG diagrams generator
│   └── classification_report.pdf   # Model evaluation PDF sheet
├── scripts/
│   ├── train_dapt.py               # Masked Language Modeling training script
│   ├── train_classifier.py         # Classifier fine-tuning script
│   └── evaluate_classifier.py      # Classifier evaluation plotter
└── README.md
```

---

## 🚀 Setup & Local Execution Guide

### 1. Prerequisites
- **Python 3.9+**
- **Node.js v18+ & npm**

### 2. Environment Installation

In the project root workspace directory:

```bash
# Initialize and activate Python virtual environment
python3 -m venv venv
source venv/bin/activate

# Upgrade pip and install backend packages
pip install --upgrade pip
pip install -r backend/requirements.txt

# Install Angular frontend dependencies
cd frontend
npm install
cd ..
```

---

### 3. Running the Machine Learning Pipelines

Before starting the FastAPI application, run the data pipeline and model validation scripts to compile baseline results:

```bash
# Activate virtual environment
source venv/bin/activate

# Phase 1: Compile datasets and generate statistics HTML report
python datasets/download_and_prep.py

# Phase 9: Train baselines (SVM/RF) and generate comparative metrics CSV
python research/compare_models.py

# Phase 10: Generate publication diagrams (Architecture, DFD, ER, use case, etc.)
python research/generate_diagrams.py

# Phase 3: Evaluate model performance and compile classification_report.pdf
python scripts/evaluate_classifier.py
```

> [!NOTE]
> **Domain pretraining (DAPT)** and **classifier fine-tuning** on RoBERTa can be initiated using:
> `python scripts/train_dapt.py`
> `python scripts/train_classifier.py`
> Pass the `--fast_run` argument (e.g., `python scripts/train_classifier.py --fast_run`) to execute a rapid training loop on a small subset (ideal for CPU validation).

---

### 4. Running the Application Services

To start the system, open two terminal windows:

#### Terminal 1: Launch FastAPI Backend Server
```bash
source venv/bin/activate
python3 -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload
```
The REST API documentation will be available immediately at: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs).

#### Terminal 2: Launch Angular Frontend Dev Server
```bash
cd frontend
npm run start
```
The premium user interface dashboard will be available at: [http://localhost:4200](http://localhost:4200).

---

## 🛡️ API Endpoints Documentation

| HTTP Method | Route Path | Description |
| :--- | :--- | :--- |
| **POST** | `/api/v1/auth/signup` | Create user profile |
| **POST** | `/api/v1/auth/login` | Authenticate user & receive JWT token |
| **POST** | `/api/v1/predict` | Predict ambiguity and get SHAP/LIME plots |
| **POST** | `/api/v1/refine` | Refine requirement text using rules & Flan-T5 |
| **POST** | `/api/v1/upload` | Parse CSV, process batch predictions |
| **GET** | `/api/v1/metrics` | Retrieve comparative metrics benchmarks |
| **GET** | `/api/v1/history` | Fetch analysis audit logs |
| **GET** | `/api/v1/reports/summary` | Fetch dashboard KPI summaries |
| **GET** | `/api/v1/reports/export/pdf` | Export full PDF compliance reports |

---

## 🎓 Academic Publications Info

This project is structured specifically to meet evaluation standards for **IEEE Papers, B.Tech/MCA major project defenses, and Journal publications**.
The programmatically generated figures in the `research/` directory provide publication-ready graphics for the Methodology, Results, and Analysis sections of academic submittals.
