import os
import argparse
import pandas as pd
import torch
from transformers import (
    AutoTokenizer,
    AutoModelForMaskedLM,
    DataCollatorForLanguageModeling,
    Trainer,
    TrainingArguments,
    EarlyStoppingCallback
)
from datasets import Dataset

def main():
    parser = argparse.ArgumentParser(description="Domain-Adaptive Pretraining on RoBERTa")
    parser.add_argument("--fast_run", action="store_true", help="Run a quick pretraining with 1 epoch and small subset")
    args = parser.parse_args()

    print("Starting Domain-Adaptive Pretraining (DAPT) workflow...")

    # Load dataset
    data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "datasets")
    train_path = os.path.join(data_dir, "train.csv")
    val_path = os.path.join(data_dir, "validation.csv")

    if not os.path.exists(train_path) or not os.path.exists(val_path):
        raise FileNotFoundError(f"Cleaned training/validation files not found in {data_dir}. Run download_and_prep.py first.")

    train_df = pd.read_csv(train_path)
    val_df = pd.read_csv(val_path)

    # In MLM we only need text
    train_texts = train_df['requirement_text'].dropna().tolist()
    val_texts = val_df['requirement_text'].dropna().tolist()

    if args.fast_run:
        print("Fast run activated: limiting dataset to 20 samples and training to 1 epoch")
        train_texts = train_texts[:20]
        val_texts = val_texts[:10]

    # Initialize tokenizer and model
    model_name = "roberta-base"
    print(f"Loading pretrained model and tokenizer: {model_name}...")
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForMaskedLM.from_pretrained(model_name)

    # Tokenization helper
    def tokenize_function(examples):
        return tokenizer(examples["text"], truncation=True, padding="max_length", max_length=128)

    # Create HuggingFace datasets
    train_dataset = Dataset.from_dict({"text": train_texts})
    val_dataset = Dataset.from_dict({"text": val_texts})

    print("Tokenizing datasets...")
    tokenized_train = train_dataset.map(tokenize_function, batched=True, remove_columns=["text"])
    tokenized_val = val_dataset.map(tokenize_function, batched=True, remove_columns=["text"])

    # Data collator for MLM
    data_collator = DataCollatorForLanguageModeling(
        tokenizer=tokenizer,
        mlm=True,
        mlm_probability=0.15
    )

    output_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models", "domain_roberta")
    os.makedirs(output_dir, exist_ok=True)

    # Training arguments
    epochs = 1 if args.fast_run else 3
    training_args = TrainingArguments(
        output_dir=output_dir,
        overwrite_output_dir=True,
        num_train_epochs=epochs,
        per_device_train_batch_size=8 if not args.fast_run else 2,
        per_device_eval_batch_size=8 if not args.fast_run else 2,
        evaluation_strategy="epoch",
        save_strategy="epoch",
        learning_rate=5e-5,
        weight_decay=0.01,
        logging_dir=os.path.join(output_dir, "logs"),
        logging_steps=10 if args.fast_run else 50,
        load_best_model_at_end=True,
        metric_for_best_model="loss",
        greater_is_better=False,
        report_to="none",  # Disable wandb/comet logs
        fp16=torch.cuda.is_available()
    )

    # Initialize Trainer
    trainer = Trainer(
        model=model,
        args=training_args,
        data_collator=data_collator,
        train_dataset=tokenized_train,
        eval_dataset=tokenized_val,
        callbacks=[EarlyStoppingCallback(early_stopping_patience=2)]
    )

    # Train model
    print("Training Domain-Adaptive RoBERTa model...")
    trainer.train()

    # Save model and tokenizer
    print(f"Saving fine-tuned Domain-Adaptive model to {output_dir}...")
    trainer.save_model(output_dir)
    tokenizer.save_pretrained(output_dir)
    print("Domain-Adaptive Pretraining complete!")

if __name__ == "__main__":
    main()
