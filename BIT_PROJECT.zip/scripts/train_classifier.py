import os
import argparse
import pandas as pd
import numpy as np
import torch
from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    Trainer,
    TrainingArguments,
    EarlyStoppingCallback
)
from datasets import Dataset
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, roc_auc_score

def compute_metrics(eval_pred):
    predictions, labels = eval_pred
    # Apply softmax or argmax
    preds = np.argmax(predictions, axis=1)
    
    # Calculate metrics
    precision, recall, f1, _ = precision_recall_fscore_support(labels, preds, average='binary')
    acc = accuracy_score(labels, preds)
    
    # Compute probabilities for AUC
    # Softmax conversion
    exp_preds = np.exp(predictions)
    probs = exp_preds / np.sum(exp_preds, axis=1, keepdims=True)
    try:
        auc = roc_auc_score(labels, probs[:, 1])
    except Exception:
        auc = 0.0
        
    return {
        "accuracy": acc,
        "f1": f1,
        "precision": precision,
        "recall": recall,
        "roc_auc": auc
    }

def main():
    parser = argparse.ArgumentParser(description="Ambiguity Classifier Fine-Tuning")
    parser.add_argument("--fast_run", action="store_true", help="Run a quick training with 1 epoch and small subset")
    args = parser.parse_args()

    print("Starting Ambiguity Classifier Fine-Tuning workflow...")

    # Define paths
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    data_dir = os.path.join(base_dir, "datasets")
    train_path = os.path.join(data_dir, "train.csv")
    val_path = os.path.join(data_dir, "validation.csv")

    if not os.path.exists(train_path) or not os.path.exists(val_path):
        raise FileNotFoundError(f"Cleaned training/validation files not found in {data_dir}. Run download_and_prep.py first.")

    train_df = pd.read_csv(train_path)
    val_df = pd.read_csv(val_path)

    if args.fast_run:
        print("Fast run activated: limiting dataset to 20 samples and training to 1 epoch")
        train_df = train_df.head(20)
        val_df = val_df.head(10)

    # Check for DAPT model, fallback to roberta-base
    dapt_path = os.path.join(base_dir, "models", "domain_roberta")
    if os.path.exists(dapt_path) and any(f for f in os.listdir(dapt_path) if f != "logs"):
        model_source = dapt_path
        print(f"Loading custom Domain-Adaptive RoBERTa model from: {dapt_path}")
    else:
        model_source = "roberta-base"
        print(f"Domain-Adaptive model not found at {dapt_path}. Falling back to baseline 'roberta-base'.")

    # Load tokenizer and model
    tokenizer = AutoTokenizer.from_pretrained(model_source)
    model = AutoModelForSequenceClassification.from_pretrained(model_source, num_labels=2)

    # Tokenize function
    def tokenize_function(examples):
        return tokenizer(examples["requirement_text"], truncation=True, padding="max_length", max_length=128)

    # Convert pandas dataframe to HuggingFace dataset
    train_dataset = Dataset.from_pandas(train_df[['requirement_text', 'label']])
    val_dataset = Dataset.from_pandas(val_df[['requirement_text', 'label']])

    print("Tokenizing datasets...")
    tokenized_train = train_dataset.map(tokenize_function, batched=True)
    tokenized_val = val_dataset.map(tokenize_function, batched=True)

    # Output directory
    output_dir = os.path.join(base_dir, "models", "classifier")
    os.makedirs(output_dir, exist_ok=True)

    # Training arguments
    epochs = 1 if args.fast_run else 3
    training_args = TrainingArguments(
        output_dir=output_dir,
        overwrite_output_dir=True,
        num_train_epochs=epochs,
        per_device_train_batch_size=8 if not args.fast_run else 2,
        per_device_eval_batch_size=8 if not args.fast_run else 2,
        evaluation_strategy="epoch",
        save_strategy="epoch",
        learning_rate=2e-5,
        weight_decay=0.01,
        logging_dir=os.path.join(output_dir, "logs"),
        logging_steps=5 if args.fast_run else 20,
        load_best_model_at_end=True,
        metric_for_best_model="f1",
        greater_is_better=True,
        report_to="none",
        fp16=torch.cuda.is_available()
    )

    # Initialize Trainer
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized_train,
        eval_dataset=tokenized_val,
        compute_metrics=compute_metrics,
        callbacks=[EarlyStoppingCallback(early_stopping_patience=2)]
    )

    # Train model
    print("Training classifier model...")
    trainer.train()

    # Save classifier model and tokenizer
    print(f"Saving fine-tuned classifier model to {output_dir}...")
    trainer.save_model(output_dir)
    tokenizer.save_pretrained(output_dir)
    print("Classifier training complete!")

if __name__ == "__main__":
    main()
