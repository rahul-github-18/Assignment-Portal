import os
import argparse
import pandas as pd
import numpy as np
import torch
import matplotlib.pyplot as plt
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    roc_auc_score,
    confusion_matrix,
    roc_curve,
    ConfusionMatrixDisplay
)
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

def main():
    parser = argparse.ArgumentParser(description="Ambiguity Classifier Evaluation")
    args = parser.parse_args()

    print("Starting Ambiguity Classifier Evaluation...")

    # Define paths
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    data_dir = os.path.join(base_dir, "datasets")
    test_path = os.path.join(data_dir, "test.csv")
    classifier_path = os.path.join(base_dir, "models", "classifier")
    research_dir = os.path.join(base_dir, "research")
    os.makedirs(research_dir, exist_ok=True)

    if not os.path.exists(test_path):
        raise FileNotFoundError(f"Test dataset not found in {data_dir}. Run download_and_prep.py first.")

    test_df = pd.read_csv(test_path)
    
    # Load tokenizer and model
    if os.path.exists(classifier_path) and any(f for f in os.listdir(classifier_path) if f != "logs"):
        model_source = classifier_path
        print(f"Loading classifier model from: {classifier_path}")
    else:
        model_source = "roberta-base"
        print(f"Classifier model not found at {classifier_path}. Falling back to baseline 'roberta-base' for validation.")

    tokenizer = AutoTokenizer.from_pretrained(model_source)
    model = AutoModelForSequenceClassification.from_pretrained(model_source, num_labels=2)
    model.eval()

    texts = test_df['requirement_text'].dropna().tolist()
    labels = test_df['label'].dropna().tolist()

    print(f"Running inference on {len(texts)} test requirements...")
    preds = []
    probs = []

    # Run batched inference to be memory efficient and faster
    batch_size = 16
    with torch.no_grad():
        for i in range(0, len(texts), batch_size):
            batch_texts = texts[i:i+batch_size]
            inputs = tokenizer(batch_texts, truncation=True, padding=True, max_length=128, return_tensors="pt")
            outputs = model(**inputs)
            logits = outputs.logits
            
            # Argmax for predictions
            batch_preds = torch.argmax(logits, dim=1).cpu().tolist()
            preds.extend(batch_preds)
            
            # Softmax for probabilities
            batch_probs = torch.softmax(logits, dim=1)[:, 1].cpu().tolist()
            probs.extend(batch_probs)

    # Compute metrics
    acc = accuracy_score(labels, preds)
    precision, recall, f1, _ = precision_recall_fscore_support(labels, preds, average='binary')
    auc = roc_auc_score(labels, probs)
    cm = confusion_matrix(labels, preds)

    print(f"Metrics Evaluated:")
    print(f" - Accuracy:  {acc:.4f}")
    print(f" - Precision: {precision:.4f}")
    print(f" - Recall:    {recall:.4f}")
    print(f" - F1 Score:  {f1:.4f}")
    print(f" - ROC-AUC:   {auc:.4f}")

    # Generate Confusion Matrix Plot
    print("Generating Confusion Matrix plot...")
    plt.figure(figsize=(6, 5))
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['Non-Ambiguous', 'Ambiguous'])
    disp.plot(cmap=plt.cm.Blues, values_format='d')
    plt.title("Confusion Matrix")
    cm_path = os.path.join(research_dir, "confusion_matrix.png")
    plt.savefig(cm_path, dpi=300, bbox_inches='tight')
    plt.close()

    # Generate ROC Curve Plot
    print("Generating ROC Curve plot...")
    plt.figure(figsize=(6, 5))
    fpr, tpr, _ = roc_curve(labels, probs)
    plt.plot(fpr, tpr, color='indigo', lw=2, label=f'RoBERTa Classifier (AUC = {auc:.2f})')
    plt.plot([0, 1], [0, 1], color='gray', lw=1, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic (ROC)')
    plt.legend(loc="lower right")
    roc_path = os.path.join(research_dir, "roc_curve.png")
    plt.savefig(roc_path, dpi=300, bbox_inches='tight')
    plt.close()

    # Generate PDF Report
    print("Generating classification_report.pdf...")
    pdf_path = os.path.join(research_dir, "classification_report.pdf")
    doc = SimpleDocTemplate(pdf_path, pagesize=letter, rightMargin=54, leftMargin=54, topMargin=54, bottomMargin=54)
    story = []

    # Styling
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'TitleStyle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=24,
        leading=28,
        textColor=colors.HexColor('#111827'),
        spaceAfter=15
    )
    subtitle_style = ParagraphStyle(
        'SubtitleStyle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=12,
        leading=16,
        textColor=colors.HexColor('#4B5563'),
        spaceAfter=25
    )
    heading_style = ParagraphStyle(
        'HeadingStyle',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=16,
        leading=20,
        textColor=colors.HexColor('#1E3A8A'),
        spaceBefore=15,
        spaceAfter=10
    )
    body_style = ParagraphStyle(
        'BodyStyle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=10.5,
        leading=14,
        textColor=colors.HexColor('#374151'),
        spaceAfter=12
    )

    story.append(Paragraph("Cross-Dataset Ambiguity Detection Model Evaluation Report", title_style))
    story.append(Paragraph("Research Phase: Phase 3 Evaluation Metric Compilation", subtitle_style))
    story.append(Spacer(1, 10))

    # Introduction
    story.append(Paragraph("Executive Summary", heading_style))
    story.append(Paragraph(
        "This evaluation report presents the performance of the Domain-Adaptive RoBERTa model for classifying software requirement specifications (SRS) into Ambiguous (1) and Non-Ambiguous (0) categories. The model has been pretrained using software engineering terminology (DAPT) and subsequently fine-tuned on a merged cross-dataset corpus.",
        body_style
    ))

    # Metrics Table
    story.append(Paragraph("Model Performance Metrics", heading_style))
    data = [
        ["Metric", "Value"],
        ["Accuracy", f"{acc * 100:.2f}%"],
        ["Precision", f"{precision * 100:.2f}%"],
        ["Recall", f"{recall * 100:.2f}%"],
        ["F1 Score", f"{f1 * 100:.2f}%"],
        ["ROC-AUC Score", f"{auc:.4f}"]
    ]
    t = Table(data, colWidths=[200, 150])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0,0), (-1,0), 8),
        ('BACKGROUND', (0,1), (-1,-1), colors.HexColor('#F3F4F6')),
        ('GRID', (0,0), (-1,-1), 1, colors.HexColor('#E5E7EB')),
        ('PADDING', (0,0), (-1,-1), 8),
        ('FONTSIZE', (0,0), (-1,-1), 10),
    ]))
    story.append(t)
    story.append(Spacer(1, 20))

    # Visualizations
    story.append(Paragraph("Performance Visualizations", heading_style))
    # We display Confusion Matrix and ROC Curve side-by-side or stacked
    # Stacked for better readability in letter format
    if os.path.exists(cm_path):
        story.append(Paragraph("1. Confusion Matrix", ParagraphStyle('Sub', parent=styles['Normal'], fontName='Helvetica-Bold', spaceBefore=5, spaceAfter=5)))
        story.append(Image(cm_path, width=280, height=233))
        story.append(Spacer(1, 15))
        
    if os.path.exists(roc_path):
        story.append(Paragraph("2. Receiver Operating Characteristic (ROC) Curve", ParagraphStyle('Sub', parent=styles['Normal'], fontName='Helvetica-Bold', spaceBefore=5, spaceAfter=5)))
        story.append(Image(roc_path, width=280, height=233))
        story.append(Spacer(1, 15))

    doc.build(story)
    print(f"Evaluation PDF Report generated successfully at: {pdf_path}")

if __name__ == "__main__":
    main()
