import json
import hashlib
from sqlalchemy.orm import Session
from backend.app import models, schemas

# Password utility using hashlib PBKDF2 for 100% cross-platform compatibility
def get_password_hash(password: str) -> str:
    salt = "cross_dataset_srs_salt_value_2026"
    hashed = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 100000)
    return hashed.hex()

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return get_password_hash(plain_password) == hashed_password

# User operations
def get_user_by_username(db: Session, username: str):
    return db.query(models.User).filter(models.User.username == username).first()

def get_user_by_email(db: Session, email: str):
    return db.query(models.User).filter(models.User.email == email).first()

def create_user(db: Session, user: schemas.UserCreate):
    hashed_pwd = get_password_hash(user.password)
    db_user = models.User(
        username=user.username,
        email=user.email,
        hashed_password=hashed_pwd
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

# Requirement & Prediction operations
def create_requirement_prediction(
    db: Session, 
    text: str, 
    label: int, 
    confidence: float, 
    lime_plot: str, 
    shap_plot: str
):
    # 1. Create requirement
    db_req = models.Requirement(text=text)
    db.add(db_req)
    db.commit()
    db.refresh(db_req)
    
    # 2. Create prediction linked to the requirement
    db_pred = models.Prediction(
        requirement_id=db_req.id,
        label=label,
        confidence=confidence,
        lime_plot=lime_plot,
        shap_plot=shap_plot
    )
    db.add(db_pred)
    db.commit()
    db.refresh(db_pred)
    
    return db_req

def get_requirement_with_prediction(db: Session, req_id: int):
    return db.query(models.Requirement).filter(models.Requirement.id == req_id).first()

def get_all_predictions(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Requirement).offset(skip).limit(limit).all()

# Refinement operations
def create_refinement(
    db: Session, 
    requirement_id: int, 
    refined_text: str, 
    reasons: list, 
    method: str
):
    db_ref = models.Refinement(
        requirement_id=requirement_id,
        refined_text=refined_text,
        reasons=json.dumps(reasons),
        method=method
    )
    db.add(db_ref)
    db.commit()
    db.refresh(db_ref)
    return db_ref

# Metrics operations
def get_metrics(db: Session):
    return db.query(models.ModelMetrics).all()

def update_metrics(db: Session, metrics: schemas.MetricSchema):
    db_metric = db.query(models.ModelMetrics).filter(models.ModelMetrics.model_name == metrics.model_name).first()
    if db_metric:
        db_metric.accuracy = metrics.accuracy
        db_metric.precision = metrics.precision
        db_metric.recall = metrics.recall
        db_metric.f1_score = metrics.f1_score
        db_metric.auc_score = metrics.auc_score
    else:
        db_metric = models.ModelMetrics(
            model_name=metrics.model_name,
            accuracy=metrics.accuracy,
            precision=metrics.precision,
            recall=metrics.recall,
            f1_score=metrics.f1_score,
            auc_score=metrics.auc_score
        )
        db.add(db_metric)
    db.commit()
    db.refresh(db_metric)
    return db_metric

# Log action history
def log_action(db: Session, action_name: str, details: str = None):
    db_history = models.AnalysisHistory(action_name=action_name, details=details)
    db.add(db_history)
    db.commit()
    db.refresh(db_history)
    return db_history

def get_action_history(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.AnalysisHistory).order_by(models.AnalysisHistory.created_at.desc()).offset(skip).limit(limit).all()
