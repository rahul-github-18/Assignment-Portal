import datetime
from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime, Boolean, Text
from sqlalchemy.orm import relationship
from backend.app.database import Base

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(100), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)

class Requirement(Base):
    __tablename__ = "requirements"
    
    id = Column(Integer, primary_key=True, index=True)
    text = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    prediction = relationship("Prediction", back_populates="requirement", uselist=False, cascade="all, delete-orphan")
    refinement = relationship("Refinement", back_populates="requirement", uselist=False, cascade="all, delete-orphan")

class Prediction(Base):
    __tablename__ = "predictions"
    
    id = Column(Integer, primary_key=True, index=True)
    requirement_id = Column(Integer, ForeignKey("requirements.id", ondelete="CASCADE"), nullable=False)
    label = Column(Integer, nullable=False) # 0 = Non-Ambiguous, 1 = Ambiguous
    confidence = Column(Float, nullable=False)
    lime_plot = Column(Text, nullable=True) # stores base64 PNG data URL
    shap_plot = Column(Text, nullable=True) # stores base64 PNG data URL
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    requirement = relationship("Requirement", back_populates="prediction")

class Refinement(Base):
    __tablename__ = "refinements"
    
    id = Column(Integer, primary_key=True, index=True)
    requirement_id = Column(Integer, ForeignKey("requirements.id", ondelete="CASCADE"), nullable=False)
    refined_text = Column(Text, nullable=False)
    reasons = Column(Text, nullable=False) # Stores JSON serialized list of reason strings
    method = Column(String(50), nullable=False) # 'Rule-Based', 'Flan-T5', 'hybrid'
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    requirement = relationship("Requirement", back_populates="refinement")

class ModelMetrics(Base):
    __tablename__ = "model_metrics"
    
    id = Column(Integer, primary_key=True, index=True)
    model_name = Column(String(100), nullable=False, unique=True)
    accuracy = Column(Float, nullable=False)
    precision = Column(Float, nullable=False)
    recall = Column(Float, nullable=False)
    f1_score = Column(Float, nullable=False)
    auc_score = Column(Float, nullable=False)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

class AnalysisHistory(Base):
    __tablename__ = "analysis_history"
    
    id = Column(Integer, primary_key=True, index=True)
    action_name = Column(String(100), nullable=False)
    details = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
