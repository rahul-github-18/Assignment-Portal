from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from backend.app.config import settings
from backend.app.database import engine, Base
from backend.app.routers import auth, predict, refine, upload, metrics, history, reports, generator

# Create all database tables on application start
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Cross-Dataset Explainable Ambiguity Detection & Automatic SRS Refinement API",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Mount research directory to serve generated diagrams and plots
app.mount("/research", StaticFiles(directory="research"), name="research")

# CORS middleware configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Allow Angular frontend to connect
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routers under prefix
api_prefix = settings.API_V1_STR
app.include_router(auth.router, prefix=api_prefix)
app.include_router(predict.router, prefix=api_prefix)
app.include_router(refine.router, prefix=api_prefix)
app.include_router(upload.router, prefix=api_prefix)
app.include_router(metrics.router, prefix=api_prefix)
app.include_router(history.router, prefix=api_prefix)
app.include_router(reports.router, prefix=api_prefix)
app.include_router(generator.router, prefix=api_prefix)

@app.get("/", tags=["Root"])
def root_endpoint():
    return {
        "status": "online",
        "project": settings.PROJECT_NAME,
        "api_documentation": "/docs"
    }
