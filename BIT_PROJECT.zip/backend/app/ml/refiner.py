import re
import threading
from transformers import pipeline

class RequirementRefiner:
    def __init__(self):
        self.t5_pipeline = None
        self.is_llm_loaded = False
        
        # Key ambiguities and their precise refined template patterns
        self.refinement_rules = [
            (r"\b(quickly|fast|speedily|rapidly)\b", "within 2.0 seconds under peak load of 100 concurrent requests", "Replaced subjective speed descriptor with a precise response time threshold (2.0s)."),
            (r"\b(efficiently|optimally|successfully)\b", "with CPU utilization below 70% and memory consumption below 2GB", "Replaced vague efficiency adjective with quantitative hardware utilization constraints."),
            (r"\b(user-friendly|easy to use|intuitive|nice)\b", "scoring greater than 80 on the System Usability Scale (SUS) test", "Quantified subjective usability as a standardized SUS usability benchmark score."),
            (r"\b(secure|safe)\b", "complying with TLS 1.3 protocol and encrypting data at rest using AES-GCM-256", "Defined security in terms of standard industry protocols (TLS 1.3, AES-256)."),
            (r"\b(robust|highly robust|resilient)\b", "operating with a Mean Time Between Failures (MTBF) of at least 720 hours", "Refined robustness to a measurable availability metric (MTBF)."),
            (r"\b(many|lots of|multiple|several|high loads)\b", "up to 10,000 concurrent active users", "Substituted vague scale adjectives with a specific numeric user ceiling."),
            (r"\b(standard|appropriate|standard hardware)\b", "conforming to the specifications of IEEE 830 standards", "Clarified subjective standards by referencing a concrete compliance document."),
            (r"\b(occasionally|sometimes|frequently|from time to time)\b", "every 24 hours at 01:00 AM UTC", "Mapped vague frequencies to a deterministic cron schedule (daily at 01:00 UTC)."),
            (r"\b(gracefully|fine|correctly)\b", "by writing a detailed trace log in JSON format and returning an HTTP 500 status code", "Specified precise system actions and outputs for error scenarios.")
        ]
        
        # Load Flan-T5 asynchronously in a background thread so as not to block API requests
        threading.Thread(target=self._load_model_async, daemon=True).start()

    def _load_model_async(self):
        try:
            print("Attempting to load local Flan-T5 for requirement refinement in the background...")
            # Using flan-t5-base which is lightweight (~990MB) and very capable
            self.t5_pipeline = pipeline(
                "text2text-generation", 
                model="google/flan-t5-base",
                device=-1 # Default to CPU to avoid CUDA setup mismatch during tests
            )
            self.is_llm_loaded = True
            print("Flan-T5 refinement pipeline loaded successfully in the background.")
        except Exception as e:
            print(f"Flan-T5 load failed or skipped in background thread: {e}. Fallback template refiner active.")

    def _rule_based_refine(self, text: str):
        refined = text
        reasons = []
        
        # Apply substitutions
        for pattern, replacement, reason in self.refinement_rules:
            # Check if keyword matches
            matches = re.findall(pattern, refined, re.IGNORECASE)
            if matches:
                # Replace matches
                refined = re.sub(pattern, replacement, refined, flags=re.IGNORECASE)
                reasons.append(reason)
                
        # If no rules matched, apply a default template
        if refined == text:
            refined = text.replace("should", "shall").replace("must", "shall")
            if "shall" not in refined:
                refined = "The system shall ensure: " + refined
            reasons.append("Applied standard 'shall' directive syntax and structured functional requirement boundaries.")
            
        return refined, reasons

    def refine(self, text: str, method: str = "hybrid"):
        # 1. Rule-Based Refinement
        rule_refined, rule_reasons = self._rule_based_refine(text)
        
        # Ensure it starts with standard SRS styling
        rule_refined = rule_refined.replace("should", "shall").replace("must", "shall")
        if not (rule_refined.lower().startswith("the system shall") or rule_refined.lower().startswith("the software shall")):
            # capitalize first word if we append
            if rule_refined.lower().startswith("system"):
                rule_refined = "The " + rule_refined
            elif not rule_refined.lower().startswith("the"):
                rule_refined = "The system shall " + rule_refined[0].lower() + rule_refined[1:]

        # 2. LLM-Based Refinement if active and requested
        if method in ["llm", "hybrid"] and self.is_llm_loaded:
            try:
                # Format instruction-following prompt for Flan-T5
                prompt = (
                    f"Task: Rewrite the following ambiguous software requirement into a precise, measurable, "
                    f"testable, and unambiguous requirement.\n"
                    f"Ambiguous requirement: '{text}'\n"
                    f"Precise rewrite:"
                )
                
                res = self.t5_pipeline(
                    prompt, 
                    max_length=64, 
                    num_beams=4, 
                    early_stopping=True
                )
                
                llm_refined = res[0]['generated_text'].strip()
                
                # Post-processing to ensure standard SRS format
                llm_refined = llm_refined.replace("should", "shall").replace("must", "shall")
                if not ("shall" in llm_refined.lower()):
                    llm_refined = rule_refined
                    reason_desc = "T5 did not output standard SRS syntax. Fallback to rule-based refinement."
                else:
                    reason_desc = "Flan-T5 sequence-to-sequence model refined text with semantic precision."
                    
                return {
                    "original": text,
                    "refined": llm_refined,
                    "reasons": rule_reasons + [reason_desc],
                    "method": "Flan-T5"
                }
            except Exception as e:
                print(f"LLM refinement failed: {e}. Mapped to rule-based engine.")
                
        # Fallback to rule-based
        return {
            "original": text,
            "refined": rule_refined,
            "reasons": rule_reasons,
            "method": "Rule-Based"
        }

# Singleton Instance
_refiner_instance = None

def get_refiner():
    global _refiner_instance
    if _refiner_instance is None:
        _refiner_instance = RequirementRefiner()
    return _refiner_instance
