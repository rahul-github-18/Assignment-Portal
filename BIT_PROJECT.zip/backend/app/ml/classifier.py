import os
import re
import torch
import numpy as np
from transformers import AutoTokenizer, AutoModelForSequenceClassification

class AmbiguityClassifier:
    def __init__(self, model_path: str = None):
        if model_path is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            model_path = os.path.join(base_dir, "models", "classifier")
        
        self.model_path = model_path
        self.tokenizer = None
        self.model = None
        self.is_nn_loaded = False
        
        # Load neural model if it exists
        if os.path.exists(model_path) and any(f for f in os.listdir(model_path) if f != "logs"):
            try:
                print(f"Loading sequence classification model from {model_path}...")
                self.tokenizer = AutoTokenizer.from_pretrained(model_path)
                self.model = AutoModelForSequenceClassification.from_pretrained(model_path)
                self.model.eval()
                self.is_nn_loaded = True
                print("Neural classifier loaded successfully.")
            except Exception as e:
                print(f"Error loading classifier model: {e}. Falling back to Rule-Based Classifier.")
        else:
            print(f"Classifier model not found at {model_path}. Initializing Rule-Based Classifier fallback.")
            
        # Ambiguity rule-based pattern matching fallback
        self.ambiguity_indicators = [
            r"\bquickly\b", r"\befficiently\b", r"\bseamlessly\b", r"\buser-friendly\b",
            r"\brobust\b", r"\bsecure\b", r"\beasy\b", r"\bminimal\b", r"\bstandard\b",
            r"\bgracefully\b", r"\bappropriate\b", r"\breasonable\b", r"\boptimally\b",
            r"\bhighly\b", r"\bfast\b", r"\bas much as possible\b", r"\bas soon as possible\b",
            r"\boccasionally\b", r"\bsometimes\b", r"\bsufficient\b", r"\badequate\b"
        ]

    def _rule_based_predict(self, text: str):
        # Calculate ambiguity score based on fuzzy keyword hits
        hits = []
        for pattern in self.ambiguity_indicators:
            if re.search(pattern, text, re.IGNORECASE):
                hits.append(pattern.replace(r"\b", ""))
        
        # Heuristic probability
        if len(hits) > 0:
            confidence = min(0.65 + 0.1 * len(hits), 0.98)
            label = 1
            probs = [1.0 - confidence, confidence]
        else:
            confidence = 0.92
            label = 0
            probs = [confidence, 1.0 - confidence]
            
        return {
            "label": label,
            "confidence": float(confidence),
            "probabilities": [float(p) for p in probs],
            "hits": hits,
            "method": "heuristic_fallback"
        }

    def predict(self, text: str):
        if not self.is_nn_loaded:
            return self._rule_based_predict(text)
            
        try:
            inputs = self.tokenizer(text, truncation=True, padding=True, max_length=128, return_tensors="pt")
            with torch.no_grad():
                outputs = self.model(**inputs)
                logits = outputs.logits
                probs = torch.softmax(logits, dim=1).squeeze().cpu().numpy()
                
            label = int(np.argmax(probs))
            confidence = float(probs[label])
            
            return {
                "label": label,
                "confidence": confidence,
                "probabilities": [float(p) for p in probs],
                "hits": [],
                "method": "domain_adaptive_roberta"
            }
        except Exception as e:
            print(f"Prediction inference error: {e}. Falling back to rules.")
            return self._rule_based_predict(text)

# Singleton Instance
_classifier_instance = None

def get_classifier():
    global _classifier_instance
    if _classifier_instance is None:
        _classifier_instance = AmbiguityClassifier()
    return _classifier_instance
