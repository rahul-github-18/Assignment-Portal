from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.app import crud, schemas, database, models
from backend.app.ml.refiner import get_refiner
from backend.app.routers.auth import get_current_user

router = APIRouter(prefix="/refine", tags=["Requirement Refinement"])

@router.post("", response_model=schemas.RefineResponse)
def refine_requirement(
    request: schemas.RefineRequest,
    db: Session = Depends(database.get_db),
    current_user = Depends(get_current_user)
):
    text = request.requirement_text.strip()
    if not text:
        raise HTTPException(status_code=400, detail="Requirement text cannot be empty")
        
    try:
        # 1. Run Refinement
        refiner = get_refiner()
        ref_res = refiner.refine(text, method=request.method)
        
        # 2. Try to link to database if requirement is already saved
        # Find last created requirement matching original text
        db_req = db.query(models.Requirement).filter(models.Requirement.text == text).order_by(models.Requirement.created_at.desc()).first()
        
        if not db_req:
            # Create a requirement entry to link the refinement
            db_req = models.Requirement(text=text)
            db.add(db_req)
            db.commit()
            db.refresh(db_req)
            
        # Write Refinement to DB
        crud.create_refinement(
            db=db,
            requirement_id=db_req.id,
            refined_text=ref_res["refined"],
            reasons=ref_res["reasons"],
            method=ref_res["method"]
        )
        
        # 3. Log history action
        crud.log_action(
            db=db,
            action_name="Requirement Refinement",
            details=f"Refined requirement ID: {db_req.id} using {ref_res['method']} method."
        )
        
        return schemas.RefineResponse(
            original=ref_res["original"],
            refined=ref_res["refined"],
            reasons=ref_res["reasons"],
            method=ref_res["method"]
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Refinement service failure: {str(e)}")
