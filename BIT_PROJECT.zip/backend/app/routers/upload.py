import io
import csv
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from backend.app import crud, schemas, database
from backend.app.ml.classifier import get_classifier
from backend.app.routers.auth import get_current_user

router = APIRouter(prefix="/upload", tags=["Bulk CSV Uploader"])

@router.post("")
def upload_csv_requirements(
    file: UploadFile = File(...),
    db: Session = Depends(database.get_db),
    current_user = Depends(get_current_user)
):
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="Only CSV files are supported")
        
    try:
        contents = file.file.read().decode("utf-8")
        csv_reader = csv.reader(io.StringIO(contents))
        
        # Parse header
        header = next(csv_reader, None)
        if not header:
            raise HTTPException(status_code=400, detail="Empty CSV file")
            
        # Try to find requirement column index
        # Expect either 'requirement_text' or similar
        req_idx = -1
        for i, h in enumerate(header):
            if h.lower().strip() in ['requirement_text', 'requirement', 'text', 'srs']:
                req_idx = i
                break
                
        # If not found, use first column
        if req_idx == -1:
            req_idx = 0
            
        classifier = get_classifier()
        total_processed = 0
        ambiguous_count = 0
        non_ambiguous_count = 0
        results = []
        
        for row in csv_reader:
            if not row or len(row) <= req_idx:
                continue
                
            req_text = row[req_idx].strip()
            if not req_text:
                continue
                
            # Run fast classifier prediction
            pred_res = classifier.predict(req_text)
            
            # Save to Database (we don't calculate SHAP/LIME in bulk uploads to ensure speed, unless explicitly requested)
            db_req = crud.create_requirement_prediction(
                db=db,
                text=req_text,
                label=pred_res["label"],
                confidence=pred_res["confidence"],
                lime_plot="",
                shap_plot=""
            )
            
            # Increment tallies
            if pred_res["label"] == 1:
                ambiguous_count += 1
            else:
                non_ambiguous_count += 1
                
            total_processed += 1
            results.append({
                "id": db_req.id,
                "requirement_text": req_text,
                "label": pred_res["label"],
                "prediction": "Ambiguous" if pred_res["label"] == 1 else "Non-Ambiguous",
                "confidence": pred_res["confidence"]
            })
            
        # Log to history
        crud.log_action(
            db=db,
            action_name="Bulk CSV Upload",
            details=f"Uploaded and processed {total_processed} requirements. Ambiguous: {ambiguous_count}, Non-Ambiguous: {non_ambiguous_count}"
        )
        
        return {
            "filename": file.filename,
            "total_processed": total_processed,
            "ambiguous_count": ambiguous_count,
            "non_ambiguous_count": non_ambiguous_count,
            "results": results
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Bulk upload processing failed: {str(e)}")
