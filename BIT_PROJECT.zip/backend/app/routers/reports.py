import io
import json
import datetime
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from backend.app import database, models, crud
from backend.app.routers.auth import get_current_user
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

router = APIRouter(prefix="/reports", tags=["System Reports & Export"])

@router.get("/summary")
def get_analysis_summary(
    db: Session = Depends(database.get_db),
    current_user = Depends(get_current_user)
):
    try:
        total = db.query(models.Requirement).count()
        amb = db.query(models.Prediction).filter(models.Prediction.label == 1).count()
        unamb = db.query(models.Prediction).filter(models.Prediction.label == 0).count()
        refined = db.query(models.Refinement).count()
        
        # Calculate average confidence
        preds = db.query(models.Prediction.confidence).all()
        avg_conf = sum([p[0] for p in preds]) / len(preds) if preds else 0.0
        
        # Track methods distribution
        methods = db.query(models.Refinement.method).all()
        method_counts = {}
        for m in methods:
            method_counts[m[0]] = method_counts.get(m[0], 0) + 1
            
        return {
            "total_requirements": total,
            "ambiguous_count": amb,
            "non_ambiguous_count": unamb,
            "refined_count": refined,
            "average_confidence": float(avg_conf),
            "refinement_methods": method_counts
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Summary retrieval failed: {str(e)}")

@router.get("/export/pdf")
def export_requirements_pdf(
    db: Session = Depends(database.get_db),
    current_user = Depends(get_current_user)
):
    try:
        # Fetch requirements joined with predictions and refinements
        reqs = db.query(models.Requirement).all()
        
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
        story = []
        
        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            'ReportTitle',
            parent=styles['Heading1'],
            fontName='Helvetica-Bold',
            fontSize=20,
            leading=24,
            textColor=colors.HexColor('#1E3A8A'),
            spaceAfter=15
        )
        body_style = ParagraphStyle(
            'ReportBody',
            parent=styles['Normal'],
            fontName='Helvetica',
            fontSize=9,
            leading=12,
            textColor=colors.HexColor('#1F2937')
        )
        
        story.append(Paragraph("Software Requirements Ambiguity & Refinement Audit Log", title_style))
        story.append(Paragraph(f"Generated on: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC", styles['Normal']))
        story.append(Spacer(1, 15))
        
        # Table columns: ID, Original Requirement, Classification, Refined Requirement
        data = [
            ["ID", "Original Requirement", "Classification", "Refined Requirement / Change Reason"]
        ]
        
        for r in reqs:
            lbl = "N/A"
            conf = 0.0
            if r.prediction:
                lbl = "Ambiguous" if r.prediction.label == 1 else "Non-Ambiguous"
                conf = r.prediction.confidence
                
            refined_text = "N/A"
            if r.refinement:
                reasons = json.loads(r.refinement.reasons)
                reasons_str = "\n".join([f"- {rs}" for rs in reasons])
                refined_text = f"Refined:\n{r.refinement.refined_text}\n\nReasons:\n{reasons_str}"
                
            # Wrap cell contents in Paragraphs to support text wrapping in Table cells
            data.append([
                str(r.id),
                Paragraph(r.text, body_style),
                Paragraph(f"<b>{lbl}</b><br/>Conf: {conf*100:.1f}%", body_style),
                Paragraph(refined_text.replace("\n", "<br/>"), body_style)
            ])
            
        # Define table column widths
        t = Table(data, colWidths=[30, 200, 100, 210])
        t.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
            ('TEXTCOLOR', (0,0), (-1,0), colors.white),
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0,0), (-1,0), 6),
            ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#D1D5DB')),
            ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor('#F9FAFB')]),
            ('PADDING', (0,0), (-1,-1), 6),
            ('FONTSIZE', (0,0), (-1,-1), 8),
        ]))
        
        story.append(t)
        doc.build(story)
        buffer.seek(0)
        
        return StreamingResponse(
            buffer,
            media_type="application/pdf",
            headers={"Content-Disposition": "attachment; filename=requirements_audit_report.pdf"}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"PDF Export failed: {str(e)}")
