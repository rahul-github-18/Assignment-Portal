import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.app import crud, schemas, database
from backend.app.ml.explainability import get_explainer
from backend.app.routers.auth import get_current_user

router = APIRouter(prefix="/predict", tags=["Classification & Explainability"])

@router.post("", response_model=schemas.PredictResponse)
def predict_requirement(
    request: schemas.PredictRequest, 
    db: Session = Depends(database.get_db),
    current_user = Depends(get_current_user)
):
    text = request.requirement_text.strip()
    if not text:
        raise HTTPException(status_code=400, detail="Requirement text cannot be empty")
        
    try:
        # 1. Run inference and get explainability analysis (SHAP & LIME)
        explainer = get_explainer()
        analysis = explainer.explain_requirement(text)
        
        # 2. Write to DB
        db_req = crud.create_requirement_prediction(
            db=db,
            text=text,
            label=analysis["label"],
            confidence=analysis["confidence"],
            lime_plot=analysis["lime_plot"],
            shap_plot=analysis["shap_plot"]
        )
        
        # 3. Log history action
        crud.log_action(
            db=db,
            action_name="Single Prediction Analysis",
            details=f"Analyzed requirement ID: {db_req.id}. Outcome: {analysis['prediction']} (Conf: {analysis['confidence']:.2f})"
        )
        
        return schemas.PredictResponse(
            requirement_id=db_req.id,
            requirement_text=db_req.text,
            prediction=analysis["prediction"],
            label=analysis["label"],
            confidence=analysis["confidence"],
            lime_explanation=analysis["lime_explanation"],
            shap_explanation=analysis["shap_explanation"],
            lime_plot=analysis["lime_plot"],
            shap_plot=analysis["shap_plot"],
            method=analysis.get("method", "RoBERTa + Local XAI"),
            created_at=db_req.created_at
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction service failure: {str(e)}")
