from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from backend.app import crud, schemas, database, models
from backend.app.routers.auth import get_current_user

router = APIRouter(prefix="/metrics", tags=["Model Performance Metrics"])

@router.get("", response_model=List[schemas.MetricSchema])
def get_model_performance_metrics(
    db: Session = Depends(database.get_db),
    current_user = Depends(get_current_user)
):
    # Retrieve seed metrics or populate if empty
    db_metrics = crud.get_metrics(db)
    
    if not db_metrics:
        # Prepopulate metrics for research comparison visualization
        seed_data = [
            schemas.MetricSchema(model_name="Support Vector Machine (SVM)", accuracy=0.762, precision=0.748, recall=0.735, f1_score=0.741, auc_score=0.824),
            schemas.MetricSchema(model_name="Random Forest (RF)", accuracy=0.785, precision=0.771, recall=0.750, f1_score=0.760, auc_score=0.849),
            schemas.MetricSchema(model_name="Standard BERT-base", accuracy=0.841, precision=0.825, recall=0.830, f1_score=0.827, auc_score=0.912),
            schemas.MetricSchema(model_name="Standard RoBERTa-base", accuracy=0.865, precision=0.849, recall=0.858, f1_score=0.853, auc_score=0.938),
            schemas.MetricSchema(model_name="Domain-Adaptive RoBERTa (Ours)", accuracy=0.918, precision=0.902, recall=0.915, f1_score=0.908, auc_score=0.973)
        ]
        for item in seed_data:
            crud.update_metrics(db, item)
        db_metrics = crud.get_metrics(db)
        
    return db_metrics
