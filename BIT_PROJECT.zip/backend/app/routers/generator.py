from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from typing import List, Dict, Any
import json
import io
import datetime
from html import escape as html_escape
from backend.app import crud, schemas, database, models
from backend.app.ml.classifier import get_classifier
from backend.app.ml.refiner import get_refiner
from backend.app.routers.auth import get_current_user
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

router = APIRouter(prefix="/generator", tags=["Requirements Generator"])

# Predefined high-quality requirements templates containing realistic ambiguities (requirement smells)
TEMPLATES: Dict[str, List[Dict[str, str]]] = {
    "e-commerce portal": [
        {"category": "Functional", "text": "The e-commerce system should search products quickly."},
        {"category": "Performance", "text": "The database should load the shopping cart details efficiently."},
        {"category": "Security", "text": "The checkout process must be secure to prevent credential leaks."},
        {"category": "Usability", "text": "The application user interface should be user-friendly for mobile device users."},
        {"category": "Reliability", "text": "The payment gateway integration should handle network dropouts gracefully."}
    ],
    "hospital management system": [
        {"category": "Functional", "text": "The system must process patient registration forms quickly."},
        {"category": "Performance", "text": "The EHR search queries should execute optimally."},
        {"category": "Security", "text": "All medical records and history reports must be highly secure."},
        {"category": "Usability", "text": "The doctor scheduling panel should be intuitive and nice."},
        {"category": "Reliability", "text": "The hospital system shall recover from power interruptions fine."}
    ],
    "library management system": [
        {"category": "Functional", "text": "The system should retrieve catalog search results quickly."},
        {"category": "Performance", "text": "Book inventory scans must update the database optimally."},
        {"category": "Security", "text": "The member portal login must be secure against password cracking."},
        {"category": "Usability", "text": "The search interface should be user-friendly for elder visitors."},
        {"category": "Reliability", "text": "Missing barcode scanner exceptions should be handled gracefully."}
    ],
    "student/school portal": [
        {"category": "Functional", "text": "The system should load student report cards fast."},
        {"category": "Performance", "text": "The course enrollment queries must run optimally under high loads."},
        {"category": "Security", "text": "Student grades data must be protected securely."},
        {"category": "Usability", "text": "The parent portal dashboard should be extremely easy to use."},
        {"category": "Reliability", "text": "Missing file uploads during homework submission should be handled fine."}
    ],
    "social media & chat platform": [
        {"category": "Functional", "text": "The system should send instant messages quickly."},
        {"category": "Performance", "text": "The media upload pipeline must run optimally."},
        {"category": "Security", "text": "End-to-end encryption must keep user chats secure."},
        {"category": "Usability", "text": "The feeds timeline screen should be user-friendly."},
        {"category": "Reliability", "text": "Connection dropouts during live calls should be handled gracefully."}
    ],
    "online banking app": [
        {"category": "Functional", "text": "The transfer funds page must complete transactions fast."},
        {"category": "Performance", "text": "The account statement PDF reports should compile optimally."},
        {"category": "Security", "text": "The transaction verification process must be highly secure."},
        {"category": "Usability", "text": "The loan application wizard should be intuitive and easy to use."},
        {"category": "Reliability", "text": "Transaction timeouts at foreign banks must be handled gracefully."}
    ],
    "ride-sharing platform": [
        {"category": "Functional", "text": "The driver matching service should find local drivers quickly."},
        {"category": "Performance", "text": "The map rendering and GPS location updates must run optimally."},
        {"category": "Security", "text": "The passenger billing and credit card details must be secure."},
        {"category": "Usability", "text": "The customer ride request screen should be user-friendly."},
        {"category": "Reliability", "text": "GPS tracking network dropouts should be handled gracefully."}
    ],
    "task/project management tool": [
        {"category": "Functional", "text": "The system should update task board columns quickly."},
        {"category": "Performance", "text": "Bulk task status imports must execute optimally."},
        {"category": "Security", "text": "Project workspaces must restrict file access securely."},
        {"category": "Usability", "text": "The dashboard metrics interface should be easy to use."},
        {"category": "Reliability", "text": "Duplicate attachment uploads must be handled gracefully."}
    ],
    "warehouse inventory management system": [
        {"category": "Functional", "text": "The system should scan and log barcode inputs quickly."},
        {"category": "Performance", "text": "Inventory stock level audits must run optimally."},
        {"category": "Security", "text": "Warehouse database records must be stored securely."},
        {"category": "Usability", "text": "The hand-held barcode reader UI should be user-friendly."},
        {"category": "Reliability", "text": "Scanner disconnection errors must be handled gracefully."}
    ],
    "smart home iot controller": [
        {"category": "Functional", "text": "The dashboard should adjust room temperature and lighting quickly."},
        {"category": "Performance", "text": "Sensor telemetry logs should upload to the cloud optimally."},
        {"category": "Security", "text": "Smart lock commands must be encrypted and secure."},
        {"category": "Usability", "text": "The mobile control panel should be intuitive and easy to use."},
        {"category": "Reliability", "text": "Sensor hardware disconnections should be handled gracefully."}
    ]
}

def generate_fallback_templates(software_type: str) -> List[Dict[str, str]]:
    formatted_type = software_type.strip()
    return [
        {"category": "Functional", "text": f"The {formatted_type} system should execute core application commands quickly."},
        {"category": "Performance", "text": f"The {formatted_type} system's main data processing queries should execute optimally."},
        {"category": "Security", "text": f"The database records and user credentials in the {formatted_type} must be stored securely."},
        {"category": "Usability", "text": f"The application user interface of the {formatted_type} should be user-friendly for all desktop and mobile users."},
        {"category": "Reliability", "text": f"The {formatted_type} system should handle unexpected exceptions and connection failures gracefully."}
    ]

@router.post("/generate", response_model=schemas.GeneratorResponse)
def generate_srs_requirements(
    request: schemas.GeneratorRequest,
    db: Session = Depends(database.get_db),
    current_user = Depends(get_current_user)
):
    software_type_input = request.software_type.strip()
    if not software_type_input:
        raise HTTPException(status_code=400, detail="Software type cannot be empty")

    # Clean matching key
    lookup_key = software_type_input.lower().replace("system", "").replace("portal", "").replace("platform", "").replace("app", "").replace("tool", "").replace("controller", "").strip()
    
    # Match against keys by checking if look up key is a substring or vice versa
    matched_key = None
    for k in TEMPLATES.keys():
        if lookup_key in k or k in lookup_key:
            matched_key = k
            break
            
    if matched_key:
        req_templates = TEMPLATES[matched_key]
    else:
        req_templates = generate_fallback_templates(software_type_input)

    classifier = get_classifier()
    refiner = get_refiner()
    
    generated_requirements = []
    
    for idx, t in enumerate(req_templates):
        text = t["text"]
        category = t["category"]
        
        # Run live classification
        class_res = classifier.predict(text)
        is_ambiguous = (class_res["label"] == 1)
        confidence = class_res["confidence"]
        
        # Run live refinement
        ref_res = refiner.refine(text, method="hybrid")
        
        generated_requirements.append(
            schemas.GeneratedRequirement(
                id=idx + 1,
                category=category,
                original_text=text,
                is_ambiguous=is_ambiguous,
                confidence=confidence,
                refined_text=ref_res["refined"],
                refinement_reasons=ref_res["reasons"],
                refinement_method=ref_res["method"]
            )
        )
        
    # Log history action for audit trail
    crud.log_action(
        db=db,
        action_name="SRS Requirement Suite Generation",
        details=f"Generated {len(generated_requirements)} requirements for software type: '{software_type_input}'."
    )
    
    return schemas.GeneratorResponse(
        software_type=software_type_input,
        requirements=generated_requirements
    )

@router.post("/save", response_model=schemas.SaveGeneratedResponse)
def save_generated_srs(
    request: schemas.SaveGeneratedRequest,
    db: Session = Depends(database.get_db),
    current_user = Depends(get_current_user)
):
    try:
        saved_count = 0
        for req in request.requirements:
            # 1. Create requirement entry
            db_req = models.Requirement(text=req.original_text)
            db.add(db_req)
            db.commit()
            db.refresh(db_req)
            
            # 2. Save prediction
            db_pred = models.Prediction(
                requirement_id=db_req.id,
                label=1 if req.is_ambiguous else 0,
                confidence=req.confidence,
                lime_plot=None,
                shap_plot=None
            )
            db.add(db_pred)
            
            # 3. Save refinement
            reasons_json = json.dumps(req.refinement_reasons)
            db_ref = models.Refinement(
                requirement_id=db_req.id,
                refined_text=req.refined_text,
                reasons=reasons_json,
                method=req.refinement_method
            )
            db.add(db_ref)
            saved_count += 1
            
        db.commit()
        
        # 4. Log audit log
        crud.log_action(
            db=db,
            action_name="Save Generated Requirements",
            details=f"Saved {saved_count} generated requirements to the database for analysis tracking."
        )
        
        return schemas.SaveGeneratedResponse(
            status="success",
            saved_count=saved_count
        )
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Database batch save failure: {str(e)}")

@router.post("/export/pdf")
def export_generated_pdf(
    request: schemas.GeneratorResponse,
    current_user = Depends(get_current_user)
):
    try:
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
        story = []
        
        styles = getSampleStyleSheet()
        
        # Define premium custom styles
        title_style = ParagraphStyle(
            'SRSTitle',
            parent=styles['Heading1'],
            fontName='Helvetica-Bold',
            fontSize=22,
            leading=26,
            textColor=colors.HexColor('#4F46E5'), # Indigo primary
            spaceAfter=10,
            alignment=1 # Center
        )
        
        subtitle_style = ParagraphStyle(
            'SRSSubtitle',
            parent=styles['Normal'],
            fontName='Helvetica-Oblique',
            fontSize=10,
            leading=14,
            textColor=colors.HexColor('#4B5563'), # Muted grey
            spaceAfter=20,
            alignment=1
        )
        
        h2_style = ParagraphStyle(
            'SRSH2',
            parent=styles['Heading2'],
            fontName='Helvetica-Bold',
            fontSize=14,
            leading=18,
            textColor=colors.HexColor('#1E293B'),
            spaceBefore=15,
            spaceAfter=8,
            keepWithNext=True
        )
        
        body_style = ParagraphStyle(
            'SRSBody',
            parent=styles['Normal'],
            fontName='Helvetica',
            fontSize=9,
            leading=12,
            textColor=colors.HexColor('#1E293B')
        )
        
        # Add Header
        escaped_software_type = html_escape(request.software_type).upper()
        story.append(Paragraph("Software Requirements Specification (SRS) Document", title_style))
        story.append(Paragraph(f"System Model Domain: {escaped_software_type}<br/>Compiled using Explainable AI (XAI) Refinement System<br/>Date: {datetime.datetime.utcnow().strftime('%Y-%m-%d')}", subtitle_style))
        story.append(Spacer(1, 10))
        
        # Introduction
        story.append(Paragraph("1. Executive Summary", h2_style))
        intro_text = (
            "This document presents a structured requirements specification suite generated for the proposed software system. "
            "Each requirement was evaluated for semantic ambiguity and requirement smells (e.g. subjective terms, unmeasurable scopes) "
            "using a Domain-Adaptive RoBERTa classifier fine-tuned on software specifications. "
            "For all detected ambiguities, a hybrid refinement engine (combining Flan-T5 generation and template rules) was applied "
            "to produce clear, measurable, and testable acceptance criteria."
        )
        story.append(Paragraph(intro_text, body_style))
        story.append(Spacer(1, 10))
        
        story.append(Paragraph("2. Requirements Evaluation & Refinement Table", h2_style))
        
        # Create Table structure
        # Columns: Req ID & Category, Original Vague Requirement, Verdict & Refined Requirement
        table_data = [
            [
                Paragraph("<b>ID & Class</b>", ParagraphStyle('H1', parent=body_style, fontName='Helvetica-Bold', textColor=colors.white)),
                Paragraph("<b>Original Draft Requirement</b><br/><i>(Contains ambiguities / smells)</i>", ParagraphStyle('H2', parent=body_style, fontName='Helvetica-Bold', textColor=colors.white)),
                Paragraph("<b>Refined Quantitative Requirement</b><br/><i>(Measurable criteria + justification)</i>", ParagraphStyle('H3', parent=body_style, fontName='Helvetica-Bold', textColor=colors.white))
            ]
        ]
        
        for r in request.requirements:
            verdict_lbl = "AMBIGUOUS" if r.is_ambiguous else "CLEAR"
            verdict_color = "#EF4444" if r.is_ambiguous else "#10B981"
            
            reasons_html = "".join([f"• {html_escape(rs)}<br/>" for rs in r.refinement_reasons])
            
            # Escape dynamic texts to prevent SAXParseException
            escaped_category = html_escape(r.category)
            escaped_original = html_escape(r.original_text)
            escaped_refined = html_escape(r.refined_text)
            escaped_method = html_escape(r.refinement_method)
            
            cell_id = f"<b>SRS-REQ-{r.id:03d}</b><br/><font color='#6366F1'>{escaped_category}</font><br/><br/><font color='{verdict_color}'><b>{verdict_lbl}</b></font><br/>Conf: {r.confidence*100:.1f}%"
            cell_original = f'"{escaped_original}"'
            cell_refined = f"<b>Refined Specification:</b><br/>\"{escaped_refined}\"<br/><br/><b>Justifications:</b><br/>{reasons_html}<br/><b>Refined by:</b> {escaped_method}"
            
            table_data.append([
                Paragraph(cell_id, body_style),
                Paragraph(cell_original, body_style),
                Paragraph(cell_refined, body_style)
            ])
            
        # Define widths
        t = Table(table_data, colWidths=[90, 200, 250])
        t.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#4F46E5')),
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('BOTTOMPADDING', (0,0), (-1,0), 8),
            ('TOPPADDING', (0,0), (-1,0), 8),
            ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E2E8F0')),
            ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor('#F8FAFC')]),
            ('PADDING', (0,0), (-1,-1), 8),
        ]))
        
        story.append(t)
        
        # Build Document
        doc.build(story)
        buffer.seek(0)
        
        clean_name = request.software_type.lower().replace(" ", "_")
        return StreamingResponse(
            buffer,
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename=srs_requirements_{clean_name}.pdf"}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"PDF generation failed: {str(e)}")
