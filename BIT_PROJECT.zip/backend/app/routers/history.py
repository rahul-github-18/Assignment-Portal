from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from backend.app import crud, schemas, database
from backend.app.routers.auth import get_current_user

router = APIRouter(prefix="/history", tags=["Audit Log & Analysis History"])

@router.get("", response_model=List[schemas.HistoryResponse])
def get_analysis_audit_history(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(database.get_db),
    current_user = Depends(get_current_user)
):
    return crud.get_action_history(db, skip=skip, limit=limit)
