from pydantic import BaseModel, EmailStr
from typing import List, Optional
import datetime

# User schemas
class UserCreate(BaseModel):
    username: str
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: int
    username: str
    email: EmailStr
    is_active: bool

    class Config:
        from_attributes = True

# Token schemas
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None

# Analysis Input schemas
class PredictRequest(BaseModel):
    requirement_text: str

# Word attribution detail
class ExplainerToken(BaseModel):
    word: str
    score: float

class PredictResponse(BaseModel):
    requirement_id: int
    requirement_text: str
    prediction: str
    label: int
    confidence: float
    lime_explanation: List[ExplainerToken]
    shap_explanation: List[ExplainerToken]
    lime_plot: Optional[str] = None
    shap_plot: Optional[str] = None
    method: str
    created_at: datetime.datetime

    class Config:
        from_attributes = True

# Refinement schemas
class RefineRequest(BaseModel):
    requirement_text: str
    method: Optional[str] = "hybrid" # "rule", "llm", "hybrid"

class RefineResponse(BaseModel):
    original: str
    refined: str
    reasons: List[str]
    method: str

# Model Metrics schemas
class MetricSchema(BaseModel):
    model_name: str
    accuracy: float
    precision: float
    recall: float
    f1_score: float
    auc_score: float

    class Config:
        from_attributes = True

# History schema
class HistoryResponse(BaseModel):
    id: int
    action_name: str
    details: Optional[str] = None
    created_at: datetime.datetime

    class Config:
        from_attributes = True

# Requirement Generator schemas
class GeneratorRequest(BaseModel):
    software_type: str

class GeneratedRequirement(BaseModel):
    id: int
    category: str
    original_text: str
    is_ambiguous: bool
    confidence: float
    refined_text: str
    refinement_reasons: List[str]
    refinement_method: str

class GeneratorResponse(BaseModel):
    software_type: str
    requirements: List[GeneratedRequirement]

class SaveGeneratedRequest(BaseModel):
    requirements: List[GeneratedRequirement]

class SaveGeneratedResponse(BaseModel):
    status: str
    saved_count: int

