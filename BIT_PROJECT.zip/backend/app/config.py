import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    PROJECT_NAME: str = "Cross-Dataset Explainable Ambiguity Detection & Refinement API"
    API_V1_STR: str = "/api/v1"
    
    # Security
    SECRET_KEY: str = os.getenv("SECRET_KEY", "7ef16ac2386dae0345bfbe12674e2d312bc85ff63c0c1b48b940989f5aef409a")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7 # 1 week
    
    # DB configuration
    # Hardcoded to SQLite completely
    DATABASE_URL: str = "sqlite:///./app.db"
    
    # Models Paths
    CLASSIFIER_PATH: str = os.getenv("CLASSIFIER_PATH", "models/classifier")
    DAPT_PATH: str = os.getenv("DAPT_PATH", "models/domain_roberta")

    class Config:
        case_sensitive = True

settings = Settings()
