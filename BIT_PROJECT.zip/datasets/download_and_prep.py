import os
import re
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from collections import Counter
import json

# Define directories
DATA_DIR = os.path.dirname(os.path.abspath(__file__))
TRAIN_PATH = os.path.join(DATA_DIR, "train.csv")
VAL_PATH = os.path.join(DATA_DIR, "validation.csv")
TEST_PATH = os.path.join(DATA_DIR, "test.csv")
REPORT_PATH = os.path.join(DATA_DIR, "dataset_report.html")

# 1. Base requirements database for synthesis to ensure a high-quality, domain-specific dataset
BASE_AMBIGUOUS = [
    "The system should quickly process requests.",
    "The software must be extremely user-friendly and highly robust.",
    "Users should have appropriate access rights to view standard reports.",
    "The system shall handle high loads efficiently.",
    "The user interface should load within a reasonable amount of time.",
    "The application must be secure and fast.",
    "The database must support many concurrent users.",
    "All reports should be printed successfully.",
    "The system should have the capability to handle all types of inputs.",
    "Errors should be handled gracefully.",
    "The user should find it easy to navigate the site.",
    "The network latency should be minimal.",
    "The page loading speed must be optimized as much as possible.",
    "The system shall run on standard hardware configuration.",
    "The system should occasionally backup database contents.",
    "The UI should look nice and behave as expected.",
    "The search feature should return relevant results quickly.",
    "Large files must be handled correctly by the import script.",
    "The app should use minimal battery on mobile devices.",
    "Notifications should be sent immediately after an event.",
    "The response times should be optimized for a good user experience.",
    "The system must be secure against all hacking attempts.",
    "The software should be compatible with most web browsers.",
    "Administrator settings must be highly configurable.",
    "We need a robust solution for user authentication.",
    "The system should process calculations fast enough so the user does not wait.",
    "Only standard reports must be generated automatically.",
    "The application should support standard mobile devices.",
    "Data transfers should be encrypted using strong encryption.",
    "The system must recover from crashes within a reasonable timeframe.",
    "Error logs should contain all necessary information.",
    "The login page must load rapidly.",
    "The portal should work fine on internet explorer and other legacy browsers.",
    "We need an intuitive wizard for setting up campaigns.",
    "The system should automatically scale during peak hours.",
    "The system must prevent unauthorized access to sensitive fields.",
    "The data cleanup job should run from time to time.",
    "The user must be warned before performing critical actions.",
    "System messages should be clear and understandable.",
    "The software should handle network disconnections gracefully.",
    "We must use a modern database engine for storing transaction logs.",
    "The client should receive updates frequently.",
    "The reports should display accurate information in a nice layout.",
    "The system must be available almost all the time.",
    "High priority items should be processed first."
]

BASE_UNAMBIGUOUS = [
    "The system shall process requests within 2.0 seconds under a load of 100 concurrent requests.",
    "The software shall have a System Usability Scale (SUS) score greater than 80 and run without failure for 72 consecutive hours.",
    "Users with 'Administrator' role shall have read-only access to view financial transaction reports.",
    "The system shall support 500 concurrent transactions per second with a CPU utilization below 70%.",
    "The user interface page shall load completely within 1.5 seconds on a 4G network.",
    "The application shall encrypt all data in transit using TLS 1.3 and hash passwords using bcrypt with a work factor of 12.",
    "The database shall support 10,000 concurrent active database connections.",
    "The system shall write a confirmation log to the printer queue and return a success status code when a print request is processed.",
    "The system shall accept alphanumeric text inputs up to 256 characters and reject inputs containing SQL injection characters.",
    "The system shall log all validation errors to the error database table and display an error message containing the field name and validation rule to the user.",
    "The system shall allow users to navigate to the homepage from any screen with a single mouse click.",
    "The average network latency between the web client and the server shall be less than 50 milliseconds.",
    "The web page load time shall be less than 800 milliseconds under normal load conditions.",
    "The system shall operate on a CPU with a minimum of 4 cores, 8GB RAM, and running Ubuntu 22.04 LTS.",
    "The system shall perform a database backup every 24 hours at 02:00 AM UTC.",
    "The UI shall conform to the WCAG 2.1 Level AA accessibility guidelines.",
    "The search query shall return matching results sorted by relevance within 500 milliseconds of user submission.",
    "The system shall support the upload of PDF and XML files up to 25MB in size.",
    "The mobile application shall consume less than 5% of battery charge per hour of active usage.",
    "The system shall dispatch email notifications via SMTP within 10 seconds of a transaction failure.",
    "The transaction API response time shall be under 200 milliseconds for 95% of requests.",
    "The system shall enforce MFA for all users attempting to access the admin portal.",
    "The website shall render correctly on Google Chrome v110+, Safari v16+, and Mozilla Firefox v110+.",
    "The administrator page shall expose 15 configurable parameters defined in Appendix B.",
    "The authentication service shall require passwords to be at least 12 characters, including 1 number and 1 special character.",
    "The system shall complete the interest rate calculation in less than 1.0 second for datasets of up to 10,000 accounts.",
    "The reporting engine shall generate PDF formats for the standard monthly billing report on the 1st of every month.",
    "The application shall support iOS version 16 and Android version 13 or higher.",
    "Data transfers shall be encrypted using AES-GCM with a 256-bit key size.",
    "The system shall restore database operations from a backup archive within 15 minutes of a critical failure.",
    "The error log entry shall record the timestamp, error code, user ID, and stack trace in JSON format.",
    "The user dashboard screen shall render fully within 1.0 second on a standard 100 Mbps broadband connection.",
    "The web portal shall be compatible with modern browsers and support HTML5 and CSS Grid layout.",
    "The setup wizard shall consist of exactly 3 sequential screens: Profile, Configuration, and Summary.",
    "The system shall automatically launch a new container instance when CPU utilization exceeds 85% for 5 consecutive minutes.",
    "The database shall restrict read access to columns containing PII to users in the HR-Admin group.",
    "The database cleanup script shall execute automatically every Sunday at 01:00 AM UTC.",
    "The system shall show a confirmation modal with 'Yes' and 'Cancel' options before deleting any record.",
    "The system shall display error messages using red text (#D32F2F) and a minimum font size of 12pt.",
    "The system shall check for network availability every 5 seconds and display an offline banner when disconnected.",
    "The log storage system shall use PostgreSQL 15 for storing and indexing transaction metadata.",
    "The mobile client shall request synchronized configuration updates every 15 minutes from the REST API.",
    "The financial report shall render in a 3-column table format containing: Date, Description, and Amount.",
    "The server API shall maintain an uptime of 99.9% calculated monthly over a rolling 30-day period.",
    "The queue dispatcher shall assign priority levels 1 (critical) through 5 (low) based on the input message type metadata."
]

# 2. Template-based Synthesizer to expand the dataset
def synthesize_data(n_samples=500):
    ambiguous_templates = [
        "The {component} must be {adjective} and {adverb} process all {data_type}.",
        "Users should be able to {action} the {component} without {adjective} delay.",
        "The {component} should handle {adjective} load conditions {adverb}.",
        "We need {adjective} mechanisms to secure {component} as much as possible.",
        "The {component} should {adverb} support most {data_type} formats.",
        "Only {adjective} users can view the {adjective} reports.",
        "The system should occasionally update {component} data.",
        "A {adjective} wizard must guide the user through {action} configuration.",
        "The application should have {adjective} performance under normal usage.",
        "Errors in {component} should be handled in a {adjective} manner."
    ]
    
    unambiguous_templates = [
        "The {component} shall process {data_type} within {metric_time} seconds.",
        "The system shall allow users to {action} the {component} with a response time under {metric_time} ms.",
        "The {component} shall support up to {metric_count} concurrent {data_type} requests.",
        "The authentication service shall enforce {metric_security} encryption for all {data_type}.",
        "The {component} shall support {metric_count} data formats specified in Document Section 4.2.",
        "The database shall restrict read access to {data_type} to users with the role '{role}'.",
        "The system shall backup the database every {metric_time} hours at 00:00 UTC.",
        "The system shall guide the user through setup using exactly {metric_count} screens.",
        "The {component} response time shall be under {metric_time} seconds for 99% of transactions.",
        "The system shall log all {component} errors with details including {data_type} and timestamp."
    ]
    
    components = ["database", "web portal", "security module", "payment gateway", "search engine", "user interface", "report generator", "network layer", "authentication system", "log processor"]
    adjectives = ["quickly", "user-friendly", "highly robust", "appropriate", "reasonable", "secure", "fast", "efficient", "optimal", "intuitive", "flexible", "modern", "reliable"]
    adverbs = ["easily", "fast", "frequently", "successfully", "gracefully", "efficiently", "quickly", "reliably", "sometimes", "occasionally"]
    data_types = ["transactions", "user logs", "files", "billing reports", "API payloads", "customer records", "images", "inputs"]
    actions = ["download", "upload", "configure", "delete", "search", "navigate", "validate", "update"]
    roles = ["Administrator", "Manager", "BillingAdmin", "HR-Staff", "Guest"]
    
    # Precise metrics
    metric_times = ["1.0", "2.0", "0.5", "1.5", "3.0", "12", "24"]
    metric_counts = ["500", "1,000", "10,000", "5", "3", "15"]
    metric_security = ["TLS 1.3", "AES-256", "bcrypt with work factor 12", "SHA-256"]
    
    synthetic_ambiguous = []
    synthetic_unambiguous = []
    
    for _ in range(n_samples):
        # Ambiguous
        tpl = np.random.choice(ambiguous_templates)
        text = tpl.format(
            component=np.random.choice(components),
            adjective=np.random.choice(adjectives),
            adverb=np.random.choice(adverbs),
            data_type=np.random.choice(data_types),
            action=np.random.choice(actions)
        )
        synthetic_ambiguous.append(text)
        
        # Unambiguous
        tpl = np.random.choice(unambiguous_templates)
        text = tpl.format(
            component=np.random.choice(components),
            data_type=np.random.choice(data_types),
            action=np.random.choice(actions),
            role=np.random.choice(roles),
            metric_time=np.random.choice(metric_times),
            metric_count=np.random.choice(metric_counts),
            metric_security=np.random.choice(metric_security)
        )
        synthetic_unambiguous.append(text)
        
    return list(set(synthetic_ambiguous)), list(set(synthetic_unambiguous))

def clean_text(text):
    # Normalize whitespaces, remove special chars, convert to lowercase for comparison
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def main():
    print("Generating and preparing datasets...")
    
    # 1. Gather baseline data
    amb_base = BASE_AMBIGUOUS
    unamb_base = BASE_UNAMBIGUOUS
    
    # 2. Synthesize additional requirements (500 samples each to hit approx 1000+ total)
    syn_amb, syn_unamb = synthesize_data(n_samples=550)
    
    all_amb = list(set([clean_text(t) for t in amb_base + syn_amb]))
    all_unamb = list(set([clean_text(t) for t in unamb_base + syn_unamb]))
    
    print(f"Total Unique Ambiguous requirements: {len(all_amb)}")
    print(f"Total Unique Non-Ambiguous requirements: {len(all_unamb)}")
    
    # Create DataFrame
    df_amb = pd.DataFrame({"requirement_text": all_amb, "label": 1})
    df_unamb = pd.DataFrame({"requirement_text": all_unamb, "label": 0})
    
    df = pd.concat([df_amb, df_unamb], ignore_index=True)
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)
    
    # 3. Train-Test-Validation Split (70% Train, 15% Val, 15% Test)
    train_df, test_val_df = train_test_split(df, test_size=0.30, random_state=42, stratify=df['label'])
    val_df, test_df = train_test_split(test_val_df, test_size=0.50, random_state=42, stratify=test_val_df['label'])
    
    # Save datasets
    train_df.to_csv(TRAIN_PATH, index=False)
    val_df.to_csv(VAL_PATH, index=False)
    test_df.to_csv(TEST_PATH, index=False)
    
    print(f"Dataset Split Completed:")
    print(f" - Train samples: {len(train_df)}")
    print(f" - Validation samples: {len(val_df)}")
    print(f" - Test samples: {len(test_df)}")
    
    # 4. Stopword & Vocabulary Analysis
    # A simple stopword list
    stopwords = set(["the", "a", "an", "and", "or", "but", "if", "then", "else", "of", "to", "for", "with", "by", "on", "at", "from", "in", "into", "is", "are", "was", "were", "be", "been", "being", "have", "has", "had", "having", "do", "does", "did", "doing", "this", "that", "these", "those"])
    
    def get_token_stats(texts):
        all_words = []
        lengths = []
        for text in texts:
            # Clean and tokenize
            tokens = re.findall(r'\b\w+\b', text.lower())
            lengths.append(len(tokens))
            all_words.extend(tokens)
            
        words_no_stop = [w for w in all_words if w not in stopwords]
        vocab = set(all_words)
        
        return {
            "total_words": len(all_words),
            "vocab_size": len(vocab),
            "lengths": lengths,
            "top_words": Counter(words_no_stop).most_common(15)
        }
    
    amb_stats = get_token_stats(df_amb['requirement_text'])
    unamb_stats = get_token_stats(df_unamb['requirement_text'])
    all_stats = get_token_stats(df['requirement_text'])
    
    # Save statistics for the HTML report
    stats_summary = {
        "total_records": len(df),
        "amb_count": len(df_amb),
        "unamb_count": len(df_unamb),
        "train_size": len(train_df),
        "val_size": len(val_df),
        "test_size": len(test_df),
        "mean_len": np.mean(all_stats['lengths']),
        "max_len": np.max(all_stats['lengths']),
        "min_len": np.min(all_stats['lengths']),
        "top_words_amb": amb_stats['top_words'],
        "top_words_unamb": unamb_stats['top_words']
    }
    
    # Generate HTML Report
    generate_html_report(stats_summary, df)

def generate_html_report(stats, df):
    # Pre-render charts as JSON to embed directly into the HTML
    top_words_amb_labels = [w[0] for w in stats['top_words_amb']]
    top_words_amb_counts = [w[1] for w in stats['top_words_amb']]
    
    top_words_unamb_labels = [w[0] for w in stats['top_words_unamb']]
    top_words_unamb_counts = [w[1] for w in stats['top_words_unamb']]
    
    samples_html = ""
    for idx, row in df.head(10).iterrows():
        lbl_class = "ambiguous-badge" if row['label'] == 1 else "unambiguous-badge"
        lbl_text = "Ambiguous" if row['label'] == 1 else "Non-Ambiguous"
        samples_html += f"""
        <tr>
            <td>{row['requirement_text']}</td>
            <td><span class="badge {lbl_class}">{lbl_text}</span></td>
        </tr>
        """
        
    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dataset Pipeline Report - Ambiguity Detection</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&family=Plus+Jakarta+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {{
            --bg-primary: #0b0f19;
            --bg-secondary: #111827;
            --bg-glass: rgba(17, 24, 39, 0.7);
            --border-glass: rgba(255, 255, 255, 0.08);
            --text-primary: #f3f4f6;
            --text-secondary: #9ca3af;
            --accent-primary: #818cf8; /* Indigo */
            --accent-secondary: #34d399; /* Emerald */
            --danger: #f87171; /* Rose */
            --glow-indigo: rgba(129, 140, 248, 0.15);
        }}
        
        body {{
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-primary);
            color: var(--text-primary);
            margin: 0;
            padding: 40px 20px;
            display: flex;
            justify-content: center;
        }}
        
        .container {{
            max-width: 1200px;
            width: 100%;
        }}
        
        header {{
            text-align: center;
            margin-bottom: 50px;
        }}
        
        h1 {{
            font-family: 'Outfit', sans-serif;
            font-size: 2.8rem;
            font-weight: 800;
            margin: 0;
            background: linear-gradient(135deg, #a5b4fc, #818cf8, #34d399);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            letter-spacing: -1px;
        }}
        
        .subtitle {{
            color: var(--text-secondary);
            font-size: 1.1rem;
            margin-top: 10px;
        }}
        
        /* Stats Grid */
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }}
        
        .stat-card {{
            background: var(--bg-glass);
            border: 1px solid var(--border-glass);
            border-radius: 16px;
            padding: 24px;
            text-align: center;
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.4);
            position: relative;
            overflow: hidden;
            transition: transform 0.3s ease;
        }}
        
        .stat-card:hover {{
            transform: translateY(-5px);
            border-color: rgba(129, 140, 248, 0.3);
        }}
        
        .stat-card::before {{
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, var(--glow-indigo) 0%, transparent 60%);
            pointer-events: none;
        }}
        
        .stat-value {{
            font-size: 2.2rem;
            font-weight: 800;
            font-family: 'Outfit', sans-serif;
            color: var(--text-primary);
            margin-bottom: 5px;
        }}
        
        .stat-label {{
            color: var(--text-secondary);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }}
        
        /* Layout Grid */
        .layout-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(48%, 1fr));
            gap: 30px;
            margin-bottom: 45px;
        }}
        
        .card {{
            background: var(--bg-glass);
            border: 1px solid var(--border-glass);
            border-radius: 20px;
            padding: 30px;
            backdrop-filter: blur(12px);
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.4);
        }}
        
        .card-title {{
            font-family: 'Outfit', sans-serif;
            font-size: 1.4rem;
            font-weight: 600;
            margin-top: 0;
            margin-bottom: 25px;
            border-bottom: 1px solid var(--border-glass);
            padding-bottom: 12px;
            color: #fff;
        }}
        
        /* Table Styling */
        table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 0.95rem;
        }}
        
        th {{
            text-align: left;
            padding: 12px 16px;
            color: var(--text-secondary);
            font-weight: 600;
            border-bottom: 2px solid var(--border-glass);
        }}
        
        td {{
            padding: 14px 16px;
            border-bottom: 1px solid var(--border-glass);
            color: var(--text-primary);
        }}
        
        tr:last-child td {{
            border-bottom: none;
        }}
        
        .badge {{
            padding: 5px 10px;
            border-radius: 8px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }}
        
        .ambiguous-badge {{
            background-color: rgba(248, 113, 113, 0.15);
            color: var(--danger);
            border: 1px solid rgba(248, 113, 113, 0.3);
        }}
        
        .unambiguous-badge {{
            background-color: rgba(52, 211, 153, 0.15);
            color: var(--accent-secondary);
            border: 1px solid rgba(52, 211, 153, 0.3);
        }}
        
        .chart-container {{
            position: relative;
            height: 320px;
            width: 100%;
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>DATASET PIPELINE REPORT</h1>
            <div class="subtitle">Cross-Dataset Explainable Ambiguity Detection & Software Requirement Refinement</div>
        </header>
        
        <!-- Stats Summary -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value">{stats['total_records']}</div>
                <div class="stat-label">Total Requirements</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" style="color: var(--danger);">{stats['amb_count']}</div>
                <div class="stat-label">Ambiguous</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" style="color: var(--accent-secondary);">{stats['unamb_count']}</div>
                <div class="stat-label">Non-Ambiguous</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{stats['train_size']} / {stats['val_size']} / {stats['test_size']}</div>
                <div class="stat-label">Train / Val / Test</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{stats['mean_len']:.1f}</div>
                <div class="stat-label">Avg Token Length</div>
            </div>
        </div>
        
        <!-- Interactive Charts -->
        <div class="layout-grid">
            <div class="card">
                <div class="card-title">Class Distribution</div>
                <div class="chart-container">
                    <canvas id="classDistChart"></canvas>
                </div>
            </div>
            <div class="card">
                <div class="card-title">Stopword-Filtered Vocabulary (Unigrams/Bigrams)</div>
                <div class="chart-container">
                    <canvas id="vocabChart"></canvas>
                </div>
            </div>
        </div>
        
        <!-- Preview Table -->
        <div class="card" style="margin-bottom: 40px;">
            <div class="card-title">Data Pipeline Preview (Sample Requirements)</div>
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>Requirement Text</th>
                            <th style="width: 180px;">Label</th>
                        </tr>
                    </thead>
                    <tbody>
                        {samples_html}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
        // Class Distribution Chart
        const ctxClass = document.getElementById('classDistChart').getContext('2d');
        new Chart(ctxClass, {{
            type: 'doughnut',
            data: {{
                labels: ['Ambiguous', 'Non-Ambiguous'],
                datasets: [{{
                    data: [{stats['amb_count']}, {stats['unamb_count']}],
                    backgroundColor: ['rgba(248, 113, 113, 0.85)', 'rgba(52, 211, 153, 0.85)'],
                    borderColor: ['#f87171', '#34d399'],
                    borderWidth: 1
                }}]
            }},
            options: {{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {{
                    legend: {{
                        position: 'bottom',
                        labels: {{ color: '#f3f4f6', font: {{ family: 'Plus Jakarta Sans' }} }}
                    }}
                }}
            }}
        }});

        // Vocabulary Word Importance Chart
        const ctxVocab = document.getElementById('vocabChart').getContext('2d');
        new Chart(ctxVocab, {{
            type: 'bar',
            data: {{
                labels: {json.dumps(top_words_amb_labels[:8] + top_words_unamb_labels[:7])},
                datasets: [
                    {{
                        label: 'Ambiguous Tokens',
                        data: {json.dumps(top_words_amb_counts[:8] + [0]*7)},
                        backgroundColor: 'rgba(248, 113, 113, 0.7)',
                        borderColor: '#f87171',
                        borderWidth: 1
                    }},
                    {{
                        label: 'Non-Ambiguous Tokens',
                        data: {json.dumps([0]*8 + top_words_unamb_counts[:7])},
                        backgroundColor: 'rgba(52, 211, 153, 0.7)',
                        borderColor: '#34d399',
                        borderWidth: 1
                    }}
                ]
            }},
            options: {{
                responsive: true,
                maintainAspectRatio: false,
                scales: {{
                    x: {{
                        grid: {{ display: false }},
                        ticks: {{ color: '#9ca3af', font: {{ family: 'Plus Jakarta Sans' }} }}
                    }},
                    y: {{
                        grid: {{ color: 'rgba(255, 255, 255, 0.05)' }},
                        ticks: {{ color: '#9ca3af', font: {{ family: 'Plus Jakarta Sans' }} }}
                    }}
                }},
                plugins: {{
                    legend: {{
                        position: 'bottom',
                        labels: {{ color: '#f3f4f6', font: {{ family: 'Plus Jakarta Sans' }} }}
                    }}
                }}
            }}
        }});
    </script>
</body>
</html>
"""
    with open(REPORT_PATH, "w", encoding="utf-8") as f:
        f.write(html_content)
    print(f"Dataset Pipeline Report saved to: {REPORT_PATH}")

if __name__ == "__main__":
    main()
