import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private apiUrl = 'http://localhost:8000/api/v1';

  constructor(private http: HttpClient) {}

  // Helper to get authorization headers
  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('access_token');
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  // Auth
  login(formData: FormData): Observable<any> {
    return this.http.post(`${this.apiUrl}/auth/login`, formData);
  }

  signup(userData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/auth/signup`, userData);
  }

  // Predict (Single Requirement)
  predictRequirement(requirementText: string): Observable<any> {
    return this.http.post(
      `${this.apiUrl}/predict`, 
      { requirement_text: requirementText },
      { headers: this.getHeaders() }
    );
  }

  // Refine Requirement
  refineRequirement(requirementText: string, method: string = 'hybrid'): Observable<any> {
    return this.http.post(
      `${this.apiUrl}/refine`,
      { requirement_text: requirementText, method: method },
      { headers: this.getHeaders() }
    );
  }

  // Bulk Upload (CSV)
  uploadCSV(file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post(
      `${this.apiUrl}/upload`,
      formData,
      { headers: this.getHeaders() }
    );
  }

  // Model Metrics
  getMetrics(): Observable<any> {
    return this.http.get(`${this.apiUrl}/metrics`, { headers: this.getHeaders() });
  }

  // Audit Logs / History
  getHistory(): Observable<any> {
    return this.http.get(`${this.apiUrl}/history`, { headers: this.getHeaders() });
  }

  // Summary Metrics Report
  getSummary(): Observable<any> {
    return this.http.get(`${this.apiUrl}/reports/summary`, { headers: this.getHeaders() });
  }

  // Export PDF url generator helper
  exportPdfUrl(): string {
    const token = localStorage.getItem('access_token') || '';
    return `${this.apiUrl}/reports/export/pdf?token=${encodeURIComponent(token)}`;
  }

  // Get PDF download as blob
  downloadPdfBlob(): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/reports/export/pdf`, {
      headers: this.getHeaders(),
      responseType: 'blob'
    });
  }

  // SRS Requirements Generator
  generateRequirements(softwareType: string): Observable<any> {
    return this.http.post(
      `${this.apiUrl}/generator/generate`,
      { software_type: softwareType },
      { headers: this.getHeaders() }
    );
  }

  saveGeneratedRequirements(requirements: any[]): Observable<any> {
    return this.http.post(
      `${this.apiUrl}/generator/save`,
      { requirements: requirements },
      { headers: this.getHeaders() }
    );
  }

  downloadGeneratedPdf(softwareType: string, requirements: any[]): Observable<Blob> {
    return this.http.post(
      `${this.apiUrl}/generator/export/pdf`,
      { software_type: softwareType, requirements: requirements },
      { headers: this.getHeaders(), responseType: 'blob' }
    );
  }
}
