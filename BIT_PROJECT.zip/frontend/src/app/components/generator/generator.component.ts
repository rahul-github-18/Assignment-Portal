import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';

interface GeneratedRequirement {
  id: number;
  category: string;
  original_text: string;
  is_ambiguous: boolean;
  confidence: number;
  refined_text: string;
  refinement_reasons: string[];
  refinement_method: string;
}

@Component({
  selector: 'app-generator',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './generator.component.html',
  styleUrls: ['./generator.component.css']
})
export class GeneratorComponent {
  softwareType = '';
  loading = false;
  saving = false;
  savedSuccessfully = false;
  results: { software_type: string; requirements: GeneratedRequirement[] } | null = null;

  // Research metrics
  ambiguousCount = 0;
  clearCount = 0;
  ambiguityRatio = 0;
  averageConfidence = 0;
  latexCode = '';
  showLatex = false;
  copied = false;

  // List of pre-defined software systems that match our backend dictionary
  predefinedTemplates = [
    { title: 'E-Commerce Portal', value: 'e-commerce portal', icon: 'bi-cart3' },
    { title: 'Hospital Management', value: 'hospital management system', icon: 'bi-hospital' },
    { title: 'Library Management', value: 'library management system', icon: 'bi-book' },
    { title: 'Student Portal', value: 'student/school portal', icon: 'bi-mortarboard' },
    { title: 'Social Media Platform', value: 'social media & chat platform', icon: 'bi-chat-left-dots' },
    { title: 'Online Banking App', value: 'online banking app', icon: 'bi-bank' },
    { title: 'Ride-Sharing Platform', value: 'ride-sharing platform', icon: 'bi-car-front' },
    { title: 'Task Manager Tool', value: 'task/project management tool', icon: 'bi-kanban' },
    { title: 'Warehouse Inventory', value: 'warehouse inventory management system', icon: 'bi-boxes' },
    { title: 'Smart Home IoT', value: 'smart home iot controller', icon: 'bi-cpu' }
  ];

  constructor(private apiService: ApiService) {}

  selectTemplate(val: string): void {
    this.softwareType = val;
    this.generateRequirements();
  }

  onGenerate(event: Event): void {
    event.preventDefault();
    this.generateRequirements();
  }

  generateRequirements(): void {
    if (!this.softwareType.trim()) return;

    this.loading = true;
    this.results = null;
    this.savedSuccessfully = false;

    this.apiService.generateRequirements(this.softwareType).subscribe({
      next: (res) => {
        this.results = res;
        this.loading = false;
        this.calculateResearchMetrics();
      },
      error: (err) => {
        this.loading = false;
        console.error('Requirements generation failed:', err);
        alert('Generation error: ' + (err.error?.detail || 'Verify backend connection.'));
      }
    });
  }

  calculateResearchMetrics(): void {
    if (!this.results || !this.results.requirements.length) return;
    
    const reqs = this.results.requirements;
    this.ambiguousCount = reqs.filter(r => r.is_ambiguous).length;
    this.clearCount = reqs.length - this.ambiguousCount;
    this.ambiguityRatio = (this.ambiguousCount / reqs.length) * 100;
    this.averageConfidence = reqs.reduce((acc, r) => acc + r.confidence, 0) / reqs.length;
    
    this.generateLatexCode();
  }

  generateLatexCode(): void {
    if (!this.results) return;
    
    const softwareName = this.results.software_type;
    
    let code = `\\begin{table}[htbp]
\\caption{Semantic Ambiguity Classification and Automated Refinement for \\text{${softwareName.toUpperCase()}} Specification Suite}
\\label{tab:srs_refinement_${softwareName.toLowerCase().replace(/[^a-z0-9]/g, '')}}
\\centering
\\begin{tabular}{|l|p{4.5cm}|l|p{5.5cm}|}
\\hline
\\textbf{Req ID} & \\textbf{Original Draft Requirement (Vague)} & \\textbf{Verdict} & \\textbf{Refined Specification (Quantitative)} \\\\ \\hline\n`;

    this.results.requirements.forEach((r) => {
      const escapedOriginal = this.escapeLatex(r.original_text);
      const escapedRefined = this.escapeLatex(r.refined_text);
      const verdict = r.is_ambiguous ? `\\textcolor{red}{\\textbf{Ambiguous}}` : `\\textcolor{green}{\\textbf{Clear}}`;
      
      code += `SRS-REQ-${r.id.toString().padStart(3, '0')} & ${escapedOriginal} & ${verdict} (Conf: ${(r.confidence*100).toFixed(0)}\\%) & ${escapedRefined} \\\\ \\hline\n`;
    });

    code += `\\end{tabular}
\\end{table}`;
    this.latexCode = code;
  }

  escapeLatex(text: string): string {
    return text
      .replace(/\\/g, '\\textbackslash{}')
      .replace(/&/g, '\\&')
      .replace(/%/g, '\\%')
      .replace(/\$/g, '\\$')
      .replace(/#/g, '\\#')
      .replace(/_/g, '\\_')
      .replace(/{/g, '\\{')
      .replace(/}/g, '\\}')
      .replace(/~/g, '\\textasciitilde{}')
      .replace(/\^/g, '\\textasciicircum{}');
  }

  copyLatex(): void {
    navigator.clipboard.writeText(this.latexCode).then(() => {
      this.copied = true;
      setTimeout(() => this.copied = false, 2000);
    });
  }

  toggleLatex(): void {
    this.showLatex = !this.showLatex;
  }

  saveToDatabase(): void {
    if (!this.results || this.saving) return;

    this.saving = true;
    this.apiService.saveGeneratedRequirements(this.results.requirements).subscribe({
      next: (res) => {
        this.saving = false;
        this.savedSuccessfully = true;
      },
      error: (err) => {
        this.saving = false;
        console.error('Failed to save requirements:', err);
        alert('Save error: ' + (err.error?.detail || 'Verify database connection.'));
      }
    });
  }

  downloadSRS(): void {
    if (!this.results) return;

    this.loading = true;
    this.apiService.downloadGeneratedPdf(this.results.software_type, this.results.requirements).subscribe({
      next: (blob) => {
        this.loading = false;
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        
        const cleanName = this.results!.software_type.toLowerCase().replace(/[^a-z0-9]/g, '_');
        link.download = `srs_requirements_${cleanName}.pdf`;
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
      },
      error: (err) => {
        this.loading = false;
        console.error('PDF generation failed:', err);
        alert('Failed to generate PDF. Verify backend service status.');
      }
    });
  }
}
