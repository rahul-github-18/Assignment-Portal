import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  metrics: any[] = [];
  downloading = false;
  
  rocError = false;
  cmError = false;

  showLatex = false;
  latexCode = '';
  copied = false;

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.loadMetrics();
  }

  loadMetrics(): void {
    this.apiService.getMetrics().subscribe({
      next: (res) => {
        this.metrics = res;
        this.generateLatex();
      },
      error: (err) => {
        console.error('Error fetching metrics table:', err);
      }
    });
  }

  generateLatex(): void {
    if (!this.metrics.length) return;
    
    let code = `\\begin{table}[htbp]
\\caption{Comparative Performance of Baseline and Proposed Models on SRS Ambiguity Classification}
\\label{tab:model_comparison}
\\centering
\\begin{tabular}{|l|c|c|c|c|c|}
\\hline
\\textbf{Model Architecture} & \\textbf{Accuracy} & \\textbf{Precision} & \\textbf{Recall} & \\textbf{F1 Score} & \\textbf{ROC-AUC} \\\\ \\hline\n`;

    this.metrics.forEach((item) => {
      const isOurs = item.model_name.includes("Ours") || item.model_name.includes("Domain-Adaptive");
      const name = isOurs ? `\\textbf{${item.model_name}}` : item.model_name;
      const f1 = (item.f1_score * 100).toFixed(1) + '\\%';
      const acc = (item.accuracy * 100).toFixed(1) + '\\%';
      const prec = (item.precision * 100).toFixed(1) + '\\%';
      const rec = (item.recall * 100).toFixed(1) + '\\%';
      const auc = item.auc_score.toFixed(3);
      
      code += `${name} & ${acc} & ${prec} & ${rec} & \\textbf{${f1}} & ${auc} \\\\ \\hline\n`;
    });

    code += `\\end{tabular}
\\end{table}`;
    this.latexCode = code;
  }

  toggleLatex(): void {
    this.showLatex = !this.showLatex;
    if (this.showLatex) {
      this.generateLatex();
    }
  }

  copyLatex(): void {
    navigator.clipboard.writeText(this.latexCode).then(() => {
      this.copied = true;
      setTimeout(() => this.copied = false, 2000);
    });
  }

  handleImageError(event: any, type: string): void {
    if (type === 'roc') {
      this.rocError = true;
    } else if (type === 'cm') {
      this.cmError = true;
    }
    event.target.style.display = 'none';
  }

  downloadComplianceReport(): void {
    this.downloading = true;
    this.apiService.downloadPdfBlob().subscribe({
      next: (blob) => {
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', `srs_ambiguity_audit_compliance_${new Date().getTime()}.pdf`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        this.downloading = false;
      },
      error: (err) => {
        console.error('PDF Generation pipeline failure:', err);
        alert('Failed to download PDF report. Verify database contains records to audit.');
        this.downloading = false;
      }
    });
  }
}
