import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-refinement',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './refinement.component.html',
  styleUrls: ['./refinement.component.css']
})
export class RefinementComponent {
  requirementText = '';
  refineMethod = 'hybrid';
  loading = false;
  refinement: any = null;

  constructor(private apiService: ApiService) {}

  onRefine(event: Event): void {
    event.preventDefault();
    if (!this.requirementText.trim()) return;

    this.loading = true;
    this.refinement = null;

    this.apiService.refineRequirement(this.requirementText, this.refineMethod).subscribe({
      next: (res) => {
        this.refinement = res;
        this.loading = false;
      },
      error: (err) => {
        this.loading = false;
        console.error('Requirement refinement failed:', err);
        alert('Refinement execution error: ' + (err.error?.detail || 'Verify backend connection.'));
      }
    });
  }

  exportRefinementPDF(): void {
    if (!this.refinement) return;
    
    // Create a beautiful text compliance report for download
    let content = `============================================================\n`;
    content += `         REQUIREMENT REFINEMENT COMPLIANCE REPORT\n`;
    content += `============================================================\n\n`;
    content += `Generated on: ${new Date().toUTCString()}\n`;
    content += `Refinement Engine: ${this.refinement.method}\n\n`;
    content += `------------------------------------------------------------\n`;
    content += `ORIGINAL SRS DRAFT:\n`;
    content += `"${this.refinement.original}"\n\n`;
    content += `REFINED TESTABLE REQUIREMENT:\n`;
    content += `"${this.refinement.refined}"\n`;
    content += `------------------------------------------------------------\n\n`;
    content += `CORRECTIVE ACTIONS & RULES MATCHED:\n`;
    
    this.refinement.reasons.forEach((reason: string, i: number) => {
      content += `${i + 1}. ${reason}\n`;
    });
    
    if (this.refinement.reasons.length === 0) {
      content += `No specific ambiguity smells triggered. Formatted text with standard SRS shall directives.\n`;
    }
    
    content += `\n============================================================\n`;
    
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `srs_refinement_report_${new Date().getTime()}.txt`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}
