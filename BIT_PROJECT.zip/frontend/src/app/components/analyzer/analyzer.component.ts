import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';

interface AnnotatedWord {
  word: string;
  color: string;
  tooltip: string;
}

@Component({
  selector: 'app-analyzer',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './analyzer.component.html',
  styleUrls: ['./analyzer.component.css']
})
export class AnalyzerComponent {
  requirementText = '';
  loading = false;
  result: any = null;
  annotatedWords: AnnotatedWord[] = [];

  constructor(private apiService: ApiService) {}

  onAnalyze(event: Event): void {
    event.preventDefault();
    if (!this.requirementText.trim()) return;

    this.loading = true;
    this.result = null;
    this.annotatedWords = [];

    this.apiService.predictRequirement(this.requirementText).subscribe({
      next: (res) => {
        this.result = res;
        this.loading = false;
        this.generateAnnotatedWords();
      },
      error: (err) => {
        this.loading = false;
        console.error('Inference pipeline execution failed:', err);
        alert('Analysis error: ' + (err.error?.detail || 'Verify backend connection.'));
      }
    });
  }

  generateAnnotatedWords(): void {
    if (!this.result || !this.result.requirement_text) return;

    const sentence = this.result.requirement_text;
    // Split by whitespace keeping punctuation attached
    const words = sentence.split(/\s+/);
    
    // Create lookup tables for SHAP and LIME word weights
    const limeLookup = new Map<string, number>();
    if (this.result.lime_explanation) {
      this.result.lime_explanation.forEach((item: any) => {
        limeLookup.set(item.word.toLowerCase(), item.score);
      });
    }

    const shapLookup = new Map<string, number>();
    if (this.result.shap_explanation) {
      this.result.shap_explanation.forEach((item: any) => {
        shapLookup.set(item.word.toLowerCase(), item.score);
      });
    }

    this.annotatedWords = words.map((w: string) => {
      // Clean word to match explanation keys
      const cleanWord = w.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, "").toLowerCase();
      
      const limeScore = limeLookup.get(cleanWord) || 0;
      const shapScore = shapLookup.get(cleanWord) || 0;
      
      let color = 'transparent';
      let tooltip = 'Neutral';

      if (limeScore > 0) {
        // Red color overlay representing positive ambiguous weight
        const alpha = Math.min(0.1 + Math.abs(limeScore) * 1.5, 0.6);
        color = `rgba(239, 68, 68, ${alpha})`;
        tooltip = `LIME weight: +${limeScore.toFixed(3)} (Ambiguous Smells)`;
      } else if (limeScore < 0) {
        // Green color overlay representing negative clarify weight
        const alpha = Math.min(0.1 + Math.abs(limeScore) * 1.5, 0.6);
        color = `rgba(16, 185, 129, ${alpha})`;
        tooltip = `LIME weight: ${limeScore.toFixed(3)} (Clarity Indicator)`;
      } else if (shapScore > 0) {
        // Indigo secondary attribution
        const alpha = Math.min(0.1 + Math.abs(shapScore) * 1.2, 0.5);
        color = `rgba(129, 140, 248, ${alpha})`;
        tooltip = `SHAP value: +${shapScore.toFixed(3)}`;
      }

      return {
        word: w + ' ',
        color: color,
        tooltip: tooltip
      };
    });
  }
}
