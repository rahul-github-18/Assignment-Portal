import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-upload',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent {
  isDragging = false;
  loading = false;
  results: any = null;
  searchQuery = '';

  constructor(private apiService: ApiService) {}

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    this.isDragging = true;
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    this.isDragging = false;
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    this.isDragging = false;
    const files = event.dataTransfer?.files;
    if (files && files.length > 0) {
      this.processFile(files[0]);
    }
  }

  onFileSelected(event: any): void {
    const files = event.target.files;
    if (files && files.length > 0) {
      this.processFile(files[0]);
    }
  }

  processFile(file: File): void {
    if (!file.name.endsWith('.csv')) {
      alert('File type error: Please upload a valid CSV file.');
      return;
    }

    this.loading = true;
    this.results = null;

    this.apiService.uploadCSV(file).subscribe({
      next: (res) => {
        this.results = res;
        this.loading = false;
      },
      error: (err) => {
        this.loading = false;
        console.error('Batch upload pipeline execution failed:', err);
        alert('Batch processing failed: ' + (err.error?.detail || 'Check server status.'));
      }
    });
  }

  filteredItems(): any[] {
    if (!this.results || !this.results.results) return [];
    if (!this.searchQuery.trim()) return this.results.results;

    const query = this.searchQuery.toLowerCase();
    return this.results.results.filter((item: any) => 
      item.requirement_text.toLowerCase().includes(query)
    );
  }

  downloadResultsCSV(): void {
    if (!this.results || !this.results.results) return;

    let csvContent = 'data:text/csv;charset=utf-8,';
    csvContent += 'ID,Requirement Text,Classification,Confidence\n';

    this.results.results.forEach((item: any) => {
      // Escape commas and quotes in requirement text
      const cleanText = item.requirement_text.replace(/"/g, '""');
      csvContent += `${item.id},"${cleanText}",${item.prediction},${item.confidence}\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `bulk_srs_analysis_${new Date().getTime()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}
