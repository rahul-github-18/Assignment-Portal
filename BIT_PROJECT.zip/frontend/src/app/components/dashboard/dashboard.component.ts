import { Component, OnInit, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, AfterViewInit {
  username = '';
  summary = {
    total_requirements: 0,
    ambiguous_count: 0,
    non_ambiguous_count: 0,
    average_confidence: 0,
    refined_count: 0
  };
  history: any[] = [];
  metrics: any[] = [];
  chart: any;

  constructor(private apiService: ApiService, private router: Router) {
    this.username = localStorage.getItem('username') || 'Analyst';
  }

  ngOnInit(): void {
    this.loadSummary();
    this.loadHistory();
  }

  ngAfterViewInit(): void {
    // Metrics require slightly deferred initialization for Chart.js element mounting
    this.loadMetricsAndDrawChart();
  }

  loadSummary(): void {
    this.apiService.getSummary().subscribe({
      next: (res) => {
        this.summary = res;
      },
      error: (err) => {
        console.error('Error fetching dashboard summary:', err);
      }
    });
  }

  loadHistory(): void {
    this.apiService.getHistory().subscribe({
      next: (res) => {
        this.history = res.slice(0, 10); // get top 10 logs
      },
      error: (err) => {
        console.error('Error fetching system history logs:', err);
      }
    });
  }

  loadMetricsAndDrawChart(): void {
    this.apiService.getMetrics().subscribe({
      next: (res) => {
        this.metrics = res;
        this.initializeChart();
      },
      error: (err) => {
        console.error('Error loading comparative metrics:', err);
      }
    });
  }

  initializeChart(): void {
    const ctx = document.getElementById('dashboardChart') as HTMLCanvasElement;
    if (!ctx) return;

    const labels = this.metrics.map(m => m.model_name);
    const accuracyData = this.metrics.map(m => m.accuracy * 100);
    const f1Data = this.metrics.map(m => m.f1_score * 100);

    this.chart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Accuracy (%)',
            data: accuracyData,
            backgroundColor: 'rgba(79, 70, 229, 0.85)',
            borderColor: '#4f46e5',
            borderWidth: 1
          },
          {
            label: 'F1-Score (%)',
            data: f1Data,
            backgroundColor: 'rgba(14, 165, 233, 0.85)',
            borderColor: '#0ea5e9',
            borderWidth: 1
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: {
            grid: { display: false },
            ticks: { color: '#475569', font: { family: 'Plus Jakarta Sans', size: 9 } }
          },
          y: {
            grid: { color: 'rgba(0, 0, 0, 0.05)' },
            ticks: { color: '#475569', font: { family: 'Plus Jakarta Sans' } },
            min: 50,
            max: 100
          }
        },
        plugins: {
          legend: {
            position: 'bottom',
            labels: { color: '#0f172a', font: { family: 'Plus Jakarta Sans' } }
          }
        }
      }
    });
  }

  logout(): void {
    localStorage.removeItem('access_token');
    localStorage.removeItem('username');
    this.router.navigate(['/auth']);
  }
}
