import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-auth',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent {
  isLogin = true;
  loading = false;
  errorMessage = '';
  successMessage = '';

  loginData = {
    username: '',
    password: ''
  };

  signupData = {
    username: '',
    email: '',
    password: ''
  };

  constructor(private apiService: ApiService, private router: Router) {
    // If already logged in, redirect to dashboard
    if (localStorage.getItem('access_token')) {
      this.router.navigate(['/dashboard']);
    }
  }

  setMode(isLogin: boolean): void {
    this.isLogin = isLogin;
    this.errorMessage = '';
    this.successMessage = '';
  }

  onLogin(event: Event): void {
    event.preventDefault();
    this.loading = true;
    this.errorMessage = '';
    
    const body = new FormData();
    body.append('username', this.loginData.username);
    body.append('password', this.loginData.password);

    this.apiService.login(body).subscribe({
      next: (res) => {
        localStorage.setItem('access_token', res.access_token);
        localStorage.setItem('username', this.loginData.username);
        this.successMessage = 'Authentication successful! Redirecting...';
        setTimeout(() => {
          this.loading = false;
          this.router.navigate(['/dashboard']);
        }, 1000);
      },
      error: (err) => {
        this.loading = false;
        this.errorMessage = err.error?.detail || 'Invalid username or password';
      }
    });
  }

  onSignup(event: Event): void {
    event.preventDefault();
    this.loading = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.apiService.signup(this.signupData).subscribe({
      next: (res) => {
        this.successMessage = 'Account created successfully! You can now Sign In.';
        this.signupData = { username: '', email: '', password: '' };
        setTimeout(() => {
          this.loading = false;
          this.isLogin = true;
        }, 1500);
      },
      error: (err) => {
        this.loading = false;
        this.errorMessage = err.error?.detail || 'Account registration failed. Please try again.';
      }
    });
  }
}
