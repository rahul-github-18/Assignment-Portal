import { Component, OnInit } from '@angular/core';
import { RouterOutlet, Router, NavigationEnd, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'frontend';
  isAuthPage = true;

  constructor(private router: Router) {}

  ngOnInit(): void {
    // Check if user is logged in on startup
    const token = localStorage.getItem('access_token');
    
    // Subscribe to router events to hide sidebar on auth page
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: any) => {
      this.isAuthPage = event.url.includes('/auth');
      
      // Route Guard Simulation: Redirect to auth if no token
      if (!this.isAuthPage && !localStorage.getItem('access_token')) {
        this.router.navigate(['/auth']);
      }
    });

    if (!token) {
      this.router.navigate(['/auth']);
    }
  }
}
