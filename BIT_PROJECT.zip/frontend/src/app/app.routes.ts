import { Routes } from '@angular/router';
import { AuthComponent } from './components/auth/auth.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AnalyzerComponent } from './components/analyzer/analyzer.component';
import { UploadComponent } from './components/upload/upload.component';
import { RefinementComponent } from './components/refinement/refinement.component';
import { ReportsComponent } from './components/reports/reports.component';
import { GeneratorComponent } from './components/generator/generator.component';

export const routes: Routes = [
  { path: 'auth', component: AuthComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'analyzer', component: AnalyzerComponent },
  { path: 'upload', component: UploadComponent },
  { path: 'refinement', component: RefinementComponent },
  { path: 'generator', component: GeneratorComponent },
  { path: 'reports', component: ReportsComponent },
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: '**', redirectTo: 'dashboard' }
];
