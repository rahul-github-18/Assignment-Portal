import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as patches

def draw_diagram_base(title, figsize=(10, 6)):
    fig, ax = plt.subplots(figsize=figsize)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.axis('off')
    # Background
    fig.patch.set_facecolor('#f8fafc')
    ax.set_facecolor('#f8fafc')
    # Title
    ax.text(5, 9.5, title, fontsize=14, fontweight='bold', ha='center', va='center', color='#1e3a8a')
    return fig, ax

def save_diagram(path):
    plt.savefig(path, dpi=300, bbox_inches='tight', facecolor='#f8fafc')
    plt.close()
    print(f"Saved diagram: {path}")

def generate_system_architecture(output_path):
    fig, ax = draw_diagram_base("1. System Architecture Diagram", (10, 7))
    
    # Draw Angular Client (Front-end)
    ax.add_patch(patches.FancyBboxPatch((0.5, 3.5), 2.0, 3.0, boxstyle="round,pad=0.1", facecolor='#f43f5e', edgecolor='#be123c', alpha=0.9))
    ax.text(1.5, 5.0, "Angular 20 UI Client\n\n- Dashboard Component\n- Analyzer Component\n- Bulk Upload Component\n- Refinement Page\n- Reports Panel", 
            ha='center', va='center', color='white', fontsize=8, fontweight='bold')
    
    # Draw API Gateway / FastAPI Server
    ax.add_patch(patches.FancyBboxPatch((3.5, 3.5), 2.5, 3.0, boxstyle="round,pad=0.1", facecolor='#06b6d4', edgecolor='#0891b2', alpha=0.9))
    ax.text(4.75, 5.0, "FastAPI Backend Engine\n\n- REST Controller (Endpoints)\n- ML Predictor Router\n- Refinement Router\n- CSV Upload Processor\n- Audit logger", 
            ha='center', va='center', color='white', fontsize=8, fontweight='bold')
    
    # Draw AI/ML Model Core
    ax.add_patch(patches.FancyBboxPatch((3.5, 0.5), 2.5, 2.0, boxstyle="round,pad=0.1", facecolor='#818cf8', edgecolor='#4f46e5', alpha=0.9))
    ax.text(4.75, 1.5, "ML & Explainability Core\n\n- Domain-Adaptive RoBERTa\n- LIME Attributor\n- SHAP attributions\n- Flan-T5 Refiner", 
            ha='center', va='center', color='white', fontsize=8, fontweight='bold')

    # Draw Database
    ax.add_patch(patches.FancyBboxPatch((7.5, 3.5), 2.0, 3.0, boxstyle="round,pad=0.1", facecolor='#10b981', edgecolor='#047857', alpha=0.9))
    ax.text(8.5, 5.0, "PostgreSQL Database\n\n- Users table\n- Requirements table\n- Predictions table\n- Refinements table\n- Model Metrics table\n- Audit Log table", 
            ha='center', va='center', color='white', fontsize=8, fontweight='bold')
            
    # Connector arrows
    # Angular -> FastAPI
    ax.annotate('', xy=(3.4, 5.2), xytext=(2.7, 5.2), arrowprops=dict(arrowstyle="<->", color="#4b5563", lw=1.5))
    # FastAPI -> DB
    ax.annotate('', xy=(7.4, 5.2), xytext=(6.2, 5.2), arrowprops=dict(arrowstyle="<->", color="#4b5563", lw=1.5))
    # FastAPI -> ML Engine
    ax.annotate('', xy=(4.75, 2.7), xytext=(4.75, 3.4), arrowprops=dict(arrowstyle="<->", color="#4b5563", lw=1.5))
    
    save_diagram(output_path)

def generate_data_flow(output_path):
    fig, ax = draw_diagram_base("2. Data Flow Diagram (DFD Level 1)")
    
    steps = [
        "Raw Requirement Text\n(Input Source)",
        "Text Normalization &\nCleaning (Phase 1)",
        "Domain RoBERTa\nClassification (Phase 3)",
        "SHAP/LIME Feature\nExplanation (Phase 4)",
        "Rule & LLM Refinement\nPipeline (Phase 5)",
        "Refined Requirement\n+ Explanation Plots"
    ]
    
    for i, step in enumerate(steps):
        # Draw process node
        x = 0.5 + i * 1.55
        y = 5.0
        ax.add_patch(patches.FancyBboxPatch((x, y-1.0), 1.3, 2.0, boxstyle="round,pad=0.1", facecolor='#3b82f6', edgecolor='#1d4ed8', alpha=0.85))
        ax.text(x + 0.65, y, step, ha='center', va='center', color='white', fontsize=8, fontweight='bold')
        
        # Connectors
        if i < len(steps) - 1:
            ax.annotate('', xy=(x + 1.45, y), xytext=(x + 1.3, y), arrowprops=dict(arrowstyle="->", color="#4b5563", lw=1.5))
            
    save_diagram(output_path)

def generate_use_case(output_path):
    fig, ax = draw_diagram_base("3. Use Case Diagram", (9, 7))
    
    # Draw Actor
    ax.plot([1.5, 1.5], [5.0, 6.0], color='black', lw=2) # Body
    ax.plot([1.5], [6.3], marker='o', markersize=15, color='black') # Head
    ax.plot([1.0, 2.0], [5.5, 5.5], color='black', lw=2) # Arms
    ax.plot([1.0, 1.5, 2.0], [4.0, 5.0, 4.0], color='black', lw=2) # Legs
    ax.text(1.5, 3.5, "Software Analyst\n/ Developer", ha='center', va='center', fontweight='bold', fontsize=9)
    
    # Draw boundary box
    ax.add_patch(patches.Rectangle((3.0, 1.0), 5.5, 8.0, fill=False, edgecolor='#94a3b8', lw=1.5))
    ax.text(5.75, 8.7, "Explainable Requirement Refinement System", ha='center', va='center', fontsize=9, color='#475569', fontweight='bold')
    
    # Use cases
    use_cases = [
        "1. Login/Authentication",
        "2. Input Single Requirement",
        "3. Inspect Ambiguity Prediction",
        "4. View SHAP/LIME Explanation",
        "5. Refine Ambiguous Statement",
        "6. Upload Batch SRS (CSV)",
        "7. Export Compliance PDF Reports"
    ]
    
    for i, uc in enumerate(use_cases):
        y = 7.5 - i * 1.0
        ax.add_patch(patches.Ellipse((5.75, y), 2.2, 0.6, facecolor='#cbd5e1', edgecolor='#475569', alpha=0.9))
        ax.text(5.75, y, uc, ha='center', va='center', fontsize=8, color='#0f172a', fontweight='bold')
        
        # Link actor to use case
        ax.annotate('', xy=(4.6, y), xytext=(2.2, 5.2), arrowprops=dict(arrowstyle="-", color="#64748b", lw=1.0))
        
    save_diagram(output_path)

def generate_activity_diagram(output_path):
    fig, ax = draw_diagram_base("4. Activity Diagram", (8, 8))
    
    # Nodes
    # Start node
    ax.add_patch(patches.Circle((5, 8.5), 0.15, facecolor='black'))
    
    # Action 1: Input SRS
    ax.add_patch(patches.FancyBboxPatch((3.5, 7.2), 3.0, 0.6, boxstyle="round,pad=0.1", facecolor='#f8fafc', edgecolor='#64748b'))
    ax.text(5, 7.5, "Input Requirement Text", ha='center', va='center', fontsize=9)
    
    # Action 2: Model Inference
    ax.add_patch(patches.FancyBboxPatch((3.5, 5.8), 3.0, 0.6, boxstyle="round,pad=0.1", facecolor='#f8fafc', edgecolor='#64748b'))
    ax.text(5, 6.1, "Predict Ambiguity", ha='center', va='center', fontsize=9)
    
    # Decision Diamond
    # vertices: top, right, bottom, left
    diamond = patches.Polygon([[5, 4.8], [6, 4.3], [5, 3.8], [4, 4.3]], facecolor='#f1f5f9', edgecolor='#64748b')
    ax.add_patch(diamond)
    ax.text(5, 4.3, "Ambiguous?", ha='center', va='center', fontsize=8, fontweight='bold')
    
    # Action 3a: Display Clarity
    ax.add_patch(patches.FancyBboxPatch((1.5, 2.5), 2.8, 0.6, boxstyle="round,pad=0.1", facecolor='#f8fafc', edgecolor='#64748b'))
    ax.text(2.9, 2.8, "Display: Non-Ambiguous", ha='center', va='center', fontsize=9)
    
    # Action 3b: Run Explanations & Refine
    ax.add_patch(patches.FancyBboxPatch((5.7, 2.5), 2.8, 0.6, boxstyle="round,pad=0.1", facecolor='#f8fafc', edgecolor='#64748b'))
    ax.text(7.1, 2.8, "Generate XAI Plots\n& Refine Requirement", ha='center', va='center', fontsize=8)
    
    # Merge/Final Join
    ax.add_patch(patches.Circle((5, 1.2), 0.2, facecolor='black', edgecolor='grey', lw=2))
    ax.add_patch(patches.Circle((5, 1.2), 0.1, facecolor='white'))
    
    # Arrows
    ax.annotate('', xy=(5, 7.9), xytext=(5, 8.35), arrowprops=dict(arrowstyle="->", color="black"))
    ax.annotate('', xy=(5, 6.5), xytext=(5, 7.15), arrowprops=dict(arrowstyle="->", color="black"))
    ax.annotate('', xy=(5, 4.9), xytext=(5, 5.75), arrowprops=dict(arrowstyle="->", color="black"))
    
    # Diamond left branch -> Non-Ambiguous
    ax.annotate('', xy=(2.9, 3.2), xytext=(4.2, 4.3), arrowprops=dict(arrowstyle="->", color="black"))
    ax.text(3.3, 4.0, "No", fontsize=8)
    
    # Diamond right branch -> Ambiguous
    ax.annotate('', xy=(7.1, 3.2), xytext=(5.8, 4.3), arrowprops=dict(arrowstyle="->", color="black"))
    ax.text(6.7, 4.0, "Yes", fontsize=8)
    
    # Join arrows
    ax.annotate('', xy=(4.8, 1.35), xytext=(2.9, 2.45), arrowprops=dict(arrowstyle="->", color="black"))
    ax.annotate('', xy=(5.2, 1.35), xytext=(7.1, 2.45), arrowprops=dict(arrowstyle="->", color="black"))
    
    save_diagram(output_path)

def generate_sequence_diagram(output_path):
    fig, ax = draw_diagram_base("5. Sequence Diagram", (10, 8))
    
    # Lifelines
    ax.plot([1.5, 1.5], [1.0, 8.0], linestyle='--', color='#94a3b8')
    ax.text(1.5, 8.2, "Analyst\n(UI)", ha='center', va='center', fontsize=9, fontweight='bold')
    
    ax.plot([4.5, 4.5], [1.0, 8.0], linestyle='--', color='#94a3b8')
    ax.text(4.5, 8.2, "FastAPI\nBackend", ha='center', va='center', fontsize=9, fontweight='bold')
    
    ax.plot([7.5, 7.5], [1.0, 8.0], linestyle='--', color='#94a3b8')
    ax.text(7.5, 8.2, "RoBERTa &\nXAI Engine", ha='center', va='center', fontsize=9, fontweight='bold')
    
    # Sequence Messages
    msgs = [
        (7.0, 1.5, 4.5, "1. POST /predict (requirement text)"),
        (6.2, 4.5, 7.5, "2. tokenize & compute logits"),
        (5.4, 7.5, 7.5, "3. calculate local LIME/SHAP attributions"),
        (4.6, 7.5, 4.5, "4. return label, confidence, base64 plots"),
        (3.8, 4.5, 4.5, "5. write requirement and prediction logs to DB"),
        (3.0, 4.5, 1.5, "6. render prediction & heatmaps on client UI"),
        (2.2, 1.5, 4.5, "7. POST /refine (original statement)"),
        (1.4, 4.5, 1.5, "8. return measurable refined requirement text")
    ]
    
    for y, x_start, x_end, label in msgs:
        if x_start == x_end:
            # Self call
            ax.annotate('', xy=(x_start + 0.3, y - 0.2), xytext=(x_start, y), 
                        arrowprops=dict(arrowstyle="->", color="#1e3a8a", connectionstyle="bar,fraction=0.2"))
            ax.text(x_start + 0.4, y - 0.1, label, fontsize=8, va='center')
        else:
            arrow_style = "->"
            line_style = "solid" if x_start < x_end else "dashed"
            ax.annotate('', xy=(x_end, y), xytext=(x_start, y), 
                        arrowprops=dict(arrowstyle=arrow_style, color="#1e3a8a", lw=1.2, linestyle=line_style))
            ax.text((x_start + x_end)/2, y + 0.15, label, fontsize=8, ha='center', va='center')
            
    save_diagram(output_path)

def generate_er_diagram(output_path):
    fig, ax = draw_diagram_base("6. Entity Relationship (ER) Diagram", (10, 8))
    
    # Draw Entities
    # 1. users
    ax.add_patch(patches.Rectangle((0.5, 5.0), 2.2, 2.5, facecolor='#eff6ff', edgecolor='#3b82f6', lw=1.5))
    ax.text(1.6, 7.2, "users (Entity)", ha='center', va='center', fontweight='bold', fontsize=9, color='#1e3a8a')
    ax.text(0.6, 5.8, "PK  id (int)\n    username (varchar)\n    email (varchar)\n    hashed_pwd (varchar)\n    is_active (bool)", fontsize=8, ha='left')
    
    # 2. requirements
    ax.add_patch(patches.Rectangle((3.8, 5.0), 2.4, 2.5, facecolor='#eff6ff', edgecolor='#3b82f6', lw=1.5))
    ax.text(5.0, 7.2, "requirements", ha='center', va='center', fontweight='bold', fontsize=9, color='#1e3a8a')
    ax.text(3.9, 5.8, "PK  id (int)\n    text (text)\n    created_at (dt)", fontsize=8, ha='left')
    
    # 3. predictions
    ax.add_patch(patches.Rectangle((7.3, 5.0), 2.4, 2.5, facecolor='#eff6ff', edgecolor='#3b82f6', lw=1.5))
    ax.text(8.5, 7.2, "predictions", ha='center', va='center', fontweight='bold', fontsize=9, color='#1e3a8a')
    ax.text(7.4, 5.6, "PK  id (int)\nFK  requirement_id (int)\n    label (int)\n    confidence (float)\n    lime_plot (text)\n    shap_plot (text)\n    created_at (dt)", fontsize=8, ha='left')
    
    # 4. refinements
    ax.add_patch(patches.Rectangle((3.8, 1.2), 2.4, 2.5, facecolor='#eff6ff', edgecolor='#3b82f6', lw=1.5))
    ax.text(5.0, 3.4, "refinements", ha='center', va='center', fontweight='bold', fontsize=9, color='#1e3a8a')
    ax.text(3.9, 2.0, "PK  id (int)\nFK  requirement_id (int)\n    refined_text (text)\n    reasons (text / json)\n    method (varchar)\n    created_at (dt)", fontsize=8, ha='left')
    
    # Relationships (Crow's Foot indicators simulated)
    # requirements -> predictions (1:1)
    ax.annotate('', xy=(7.2, 6.25), xytext=(6.3, 6.25), arrowprops=dict(arrowstyle="|-|", color="black", lw=1.2))
    ax.text(6.75, 6.4, "1 : 1", fontsize=8, ha='center')
    
    # requirements -> refinements (1:1)
    ax.annotate('', xy=(5.0, 3.8), xytext=(5.0, 4.9), arrowprops=dict(arrowstyle="|-|", color="black", lw=1.2))
    ax.text(5.2, 4.35, "1 : 1", fontsize=8, va='center')
    
    save_diagram(output_path)

def generate_research_methodology(output_path):
    fig, ax = draw_diagram_base("7. Research Methodology Diagram", (10, 7))
    
    steps = [
        "Merge SRS Corpora\n(PROMISE, PURE, Smells)",
        "Phase 1: Tokenization\n& Normalization",
        "Phase 2: Domain Adaptive\nPretraining (DAPT)",
        "Phase 3: Fine-tuning\nClassification Head",
        "Phase 4: SHAP/LIME\nWord Attribution",
        "Phase 5: Automated Refinement\n(Rules + Flan-T5)"
    ]
    
    for i, step in enumerate(steps):
        # Draw block
        x = 0.5 + i * 1.55
        y = 5.0
        ax.add_patch(patches.FancyBboxPatch((x, y-1.2), 1.3, 2.4, boxstyle="round,pad=0.1", facecolor='#f472b6', edgecolor='#db2777', alpha=0.9))
        ax.text(x + 0.65, y, step, ha='center', va='center', color='white', fontsize=8, fontweight='bold')
        
        # Connection
        if i < len(steps) - 1:
            ax.annotate('', xy=(x + 1.45, y), xytext=(x + 1.3, y), arrowprops=dict(arrowstyle="->", color="black", lw=1.2))
            
    save_diagram(output_path)

def generate_workflow_diagram(output_path):
    fig, ax = draw_diagram_base("8. System Workflow Diagram", (10, 7))
    
    # Draw horizontal swimlanes
    ax.plot([0, 10], [6.5, 6.5], color='#cbd5e1', lw=1.5)
    ax.plot([0, 10], [3.2, 3.2], color='#cbd5e1', lw=1.5)
    
    # Swimlane labels
    ax.text(0.2, 8.2, "USER / CLIENT LAYER (Angular UI)", fontsize=9, fontweight='bold', color='#475569')
    ax.text(0.2, 5.0, "API ROUTING LAYER (FastAPI)", fontsize=9, fontweight='bold', color='#475569')
    ax.text(0.2, 1.8, "COMPUTATIONAL LAYER (ML Engine)", fontsize=9, fontweight='bold', color='#475569')
    
    # Swimlane 1: Enter text
    ax.add_patch(patches.FancyBboxPatch((1.5, 7.0), 2.0, 0.8, boxstyle="round,pad=0.1", facecolor='#cbd5e1'))
    ax.text(2.5, 7.4, "Submit requirement text", ha='center', va='center', fontsize=8)
    
    # Swimlane 2: API receives
    ax.add_patch(patches.FancyBboxPatch((1.5, 4.0), 2.0, 0.8, boxstyle="round,pad=0.1", facecolor='#93c5fd'))
    ax.text(2.5, 4.4, "POST /predict received", ha='center', va='center', fontsize=8)
    
    # Swimlane 3: Compute Model & attributions
    ax.add_patch(patches.FancyBboxPatch((4.5, 1.0), 2.5, 1.0, boxstyle="round,pad=0.1", facecolor='#c084fc'))
    ax.text(5.75, 1.5, "1. RoBERTa predicts Ambiguity\n2. Compute SHAP/LIME plots\n3. Generate Flan-T5 refinement", ha='center', va='center', fontsize=7, fontweight='bold')
    
    # Swimlane 2: Return & log
    ax.add_patch(patches.FancyBboxPatch((7.5, 4.0), 2.0, 0.8, boxstyle="round,pad=0.1", facecolor='#93c5fd'))
    ax.text(8.5, 4.4, "Log to DB\n& send HTTP response", ha='center', va='center', fontsize=8)
    
    # Swimlane 1: Render Dashboard
    ax.add_patch(patches.FancyBboxPatch((7.5, 7.0), 2.0, 0.8, boxstyle="round,pad=0.1", facecolor='#a7f3d0'))
    ax.text(8.5, 7.4, "Render interactive UI,\nattributions & refiner", ha='center', va='center', fontsize=8)
    
    # Connect paths
    ax.annotate('', xy=(2.5, 5.0), xytext=(2.5, 6.8), arrowprops=dict(arrowstyle="->", color="black"))
    ax.annotate('', xy=(5.75, 2.2), xytext=(2.5, 4.0), arrowprops=dict(arrowstyle="->", color="black", connectionstyle="angle,angleA=0,angleB=90"))
    ax.annotate('', xy=(8.5, 3.8), xytext=(7.0, 1.5), arrowprops=dict(arrowstyle="->", color="black", connectionstyle="angle,angleA=90,angleB=0"))
    ax.annotate('', xy=(8.5, 6.8), xytext=(8.5, 5.0), arrowprops=dict(arrowstyle="->", color="black"))
    
    save_diagram(output_path)

def main():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    research_dir = os.path.join(base_dir, "research")
    os.makedirs(research_dir, exist_ok=True)
    
    print("Generating Academic/Research Diagrams (Phase 10)...")
    
    generate_system_architecture(os.path.join(research_dir, "system_architecture.png"))
    generate_data_flow(os.path.join(research_dir, "data_flow.png"))
    generate_use_case(os.path.join(research_dir, "use_case.png"))
    generate_activity_diagram(os.path.join(research_dir, "activity_diagram.png"))
    generate_sequence_diagram(os.path.join(research_dir, "sequence_diagram.png"))
    generate_er_diagram(os.path.join(research_dir, "er_diagram.png"))
    generate_research_methodology(os.path.join(research_dir, "research_methodology.png"))
    generate_workflow_diagram(os.path.join(research_dir, "workflow_diagram.png"))
    
    print("All research diagrams generated successfully!")

if __name__ == "__main__":
    main()
